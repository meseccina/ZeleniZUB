// Illustrator skripta za preimenovanje spot boje "Bela" u "_Bela_"

function main() {
    if (app.documents.length === 0) {
        alert("Nema otvorenog dokumenta!");
        return;
    }
    
    var doc = app.activeDocument;
    var swatches = doc.swatches;
    var renamed = false;
    
    // Traži spot boju "Bela" (bilo kojom varijantom velikih/malih slova)
    for (var i = 0; i < swatches.length; i++) {
        var swatch = swatches[i];
        var swatchName = swatch.name.toLowerCase();
        
        // Proveri da li je spot boja i da li ime sadrži "bela"
        if (swatch.color && swatch.color.typename === "SpotColor" && 
            (swatchName === "bela" || swatchName === "belа")) {
            
            // Preimenuj u "_Bela_"
            swatch.name = "_Bela_";
            renamed = true;
            break; // Prekini petlju ako je pronađeno i preimenovano
        }
    }    
}

main();