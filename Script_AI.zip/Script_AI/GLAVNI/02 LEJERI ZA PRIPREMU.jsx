var doc = app.activeDocument;

// Funkcija za kreiranje sloja
function createLayer(layerName) {
    var newLayer = doc.layers.add();
    newLayer.name = layerName;
    return newLayer;
}

// Lista željenih imena slojeva
var layerNames = ["PODLOGA", "DIZAJN", "DEKLARACIJA", "_Bela_", "RASKLOP", "KOTE"];

// Kreiranje slojeva u određenom redosledu
for (var i = 0; i < layerNames.length; i++) {
    createLayer(layerNames[i]);
}