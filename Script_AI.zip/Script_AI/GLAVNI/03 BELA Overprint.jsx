var doc = app.activeDocument;

// ===============================
// AKTIVNI ARTBOARD
// ===============================
var artboardIndex = doc.artboards.getActiveArtboardIndex();
var artboard = doc.artboards[artboardIndex];
var abRect = artboard.artboardRect; // [left, top, right, bottom]

var left = abRect[0];
var top = abRect[1];
var right = abRect[2];
var bottom = abRect[3];
var width = right - left;
var height = top - bottom;

// ===============================
// SLOJ BELA
// ===============================
var belaLayer;
try {
    belaLayer = doc.layers.getByName("BELA");
} catch (e) {
    belaLayer = doc.layers.add();
    belaLayer.name = "BELA";
}

// ===============================
// SLOJ RASKLOP
// ===============================
var rasklopLayer = null;
try {
    rasklopLayer = doc.layers.getByName("RASKLOP");
} catch (e) {
    rasklopLayer = null;
}

// ===============================
// POZICIONIRANJE BELA ISPOD RASKLOP
// (safe: visibility + lock)
// ===============================
if (rasklopLayer !== null) {

    var wasHidden = false;
    var wasLocked = false;

    if (!rasklopLayer.visible) {
        wasHidden = true;
        rasklopLayer.visible = true;
    }

    if (rasklopLayer.locked) {
        wasLocked = true;
        rasklopLayer.locked = false;
    }

    belaLayer.move(rasklopLayer, ElementPlacement.PLACEAFTER);

    if (wasLocked) {
        rasklopLayer.locked = true;
    }

    if (wasHidden) {
        rasklopLayer.visible = false;
    }
}

// ===============================
// PRAVOUGAONIK PREKO ARTBOARDA
// ===============================
var rect = belaLayer.pathItems.rectangle(top, left, width, height);
rect.stroked = false;

// ===============================
// SPOT BOJA _Bela_
// ===============================
var belaSpot = null;

for (var i = 0; i < doc.spots.length; i++) {
    if (doc.spots[i].name === "_Bela_") {
        belaSpot = doc.spots[i];
        break;
    }
}

if (!belaSpot) {
    alert('Spot boja "_Bela_" nije pronađena u Swatches!');
} else {
    var fillColor = new SpotColor();
    fillColor.spot = belaSpot;
    rect.fillColor = fillColor;
    rect.fillOverprint = true;
}
