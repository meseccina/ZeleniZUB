#target illustrator

// VERZIJA 2.0 - Pažljiva optimizacija
// Zamenjuje 12 skripti sa manjim brojem, ali čuva sve korake

// Konstante
var SYMBOL_NAMES = {
    TABELA: "MOVE TABELA 26",
    INFO: "ǀ INFO ZA STAMPU"
};

var LAYER_NAMES = {
    SIMBOLI: "Simboli",
    TABELA: "MOVE TABELA 26",
    INFO: "ǀ INFO ZA STAMPU"
};

// Glavna funkcija
function main() {
    try {
        var doc = app.activeDocument;
        
        // Korak 1: Provera simbola (kao u 01_provera_da_li_postoje_simboli.jsx)
        if (!checkSymbolsExist(doc)) {
            alert("Nisu pronađeni svi traženi simboli!");
            return;
        }
        
        // Korak 2: Deselektuj sve (kao u UnSelected.jsx)
        deselectAll();
        
        // Korak 3: Proveri simbole ponovo (kao u 02_provera_simbora.jsx)
        var existsSymbol1 = checkSymbolExists(doc, SYMBOL_NAMES.TABELA);
        var existsSymbol2 = checkSymbolExists(doc, SYMBOL_NAMES.INFO);
        
        if (!existsSymbol1) {
            alert("Simbol '" + SYMBOL_NAMES.TABELA + "' ne postoji u paleti simbola.");
            return;
        }
        
        if (!existsSymbol2) {
            alert("Simbol '" + SYMBOL_NAMES.INFO + "' ne postoji u paleti simbola.");
            return;
        }
        
        // Korak 4: Kreiraj sloj "Simboli" (kao u 03_provera_i_postavljanje_novog_lejera_simboli.jsx)
        var simboliLayer = createSimboliLayer(doc);
        
        // Korak 5: Deselektuj sve (ponovo)
        deselectAll();
        
        // Korak 6: Dodaj simbole u sloj (kao u 04_postavljanje_simbola_u_lejer_simboli.jsx)
        addSymbolsToLayer(simboliLayer, doc);
        
        // Korak 7: Deselektuj sve (ponovo)
        deselectAll();
        
        // Korak 8: Pozicioniraj simbol TABELA (kao u 05_pozicija_simbola_tabela.jsx)
        positionTabelaSymbol(doc, simboliLayer);
        
        // Korak 9: Deselektuj sve (ponovo)
        deselectAll();
        
        // Korak 10: Pozicioniraj simbol INFO (kao u 06_pozicija_simbola_info.jsx)
        positionInfoSymbol(doc, simboliLayer);
        
        // Korak 11: Deselektuj sve (ponovo)
        deselectAll();
        
        // Korak 12: Razbij simbol TABELA (kao u 07_razbijanje_simbola_tabela.jsx)
        breakTabelaSymbol(simboliLayer);
        
        // Korak 13: Deselektuj sve (ponovo)
        deselectAll();
        
        // Korak 14: Premeštanje sloja TABELA (kao u 08_glavni_sloj_tabela.jsx)
        moveTabelaLayer(doc);
        
        // Korak 15: Deselektuj sve (ponovo)
        deselectAll();
        
        // Korak 16: Razbij simbol INFO (kao u 09_razbijanje_simbola_info.jsx)
        breakInfoSymbol(simboliLayer);
        
        // Korak 17: Deselektuj sve (ponovo)
        deselectAll();
        
        // Korak 18: Premeštanje sloja INFO i isključi štampu (kao u 10_glavni_sloj_info.jsx)
        moveInfoLayer(doc);
        
        // Korak 19: Deselektuj sve (ponovo)
        deselectAll();
        
        // Korak 20: Deselektuj sve (kao u drugom UnSelected.jsx)
        deselectAll();
        
        // Korak 21: Obriši sloj "Simboli" (kao u 11_brisanje_lejera_simboli.jsx)
        deleteSimboliLayer(doc);
        
        // Uspešno završeno bez alerta
        
    } catch (error) {
        alert("Greška: " + error.message);
    }
}

// Provera da li postoje simboli (iz 01_provera_da_li_postoje_simboli.jsx)
function checkSymbolsExist(doc) {
    var symbols = doc.symbols;
    var foundSymbol1 = false;
    var foundSymbol2 = false;

    for (var i = 0; i < symbols.length; i++) {
        var symbol = symbols[i];
        if (symbol.name === SYMBOL_NAMES.INFO) {
            foundSymbol1 = true;
        } else if (symbol.name === SYMBOL_NAMES.TABELA) {
            foundSymbol2 = true;
        }
    }
    
    return foundSymbol1 && foundSymbol2;
}

// Provera da li postoji jedan simbol (iz 02_provera_simbora.jsx)
function checkSymbolExists(doc, symbolName) {
    var symbols = doc.symbols;

    for (var i = 0; i < symbols.length; i++) {
        if (symbols[i].name == symbolName) {
            return true; // Simbol je pronađen
        }
    }
    return false; // Simbol nije pronađen
}

// Deselektovanje svih objekata (iz UnSelected.jsx)
function deselectAll() {
    try {
        app.selection = null;
    } catch (e) {
        // Ignoriši greške
    }
}

// Kreiranje sloja "Simboli" (iz 03_provera_i_postavljanje_novog_lejera_simboli.jsx)
function createSimboliLayer(doc) {
    var simboliLayer = doc.layers.add();
    simboliLayer.name = LAYER_NAMES.SIMBOLI;
    simboliLayer.move(doc, ElementPlacement.PLACEATBEGINNING);
    return simboliLayer;
}

// Dodavanje simbola u sloj (iz 04_postavljanje_simbola_u_lejer_simboli.jsx)
function addSymbolsToLayer(simboliLayer, doc) {
    var symbols = doc.symbols;
    var symbol1 = symbols.getByName(SYMBOL_NAMES.INFO);
    var symbolInstance1 = simboliLayer.symbolItems.add(symbol1);
    
    var symbol2 = symbols.getByName(SYMBOL_NAMES.TABELA);
    var symbolInstance2 = simboliLayer.symbolItems.add(symbol2);
}

// Pozicioniranje simbola TABELA (iz 05_pozicija_simbola_tabela.jsx)
function positionTabelaSymbol(doc, simboliLayer) {
    var artboard = doc.artboards[0];
    var artboardHeight = artboard.artboardRect[3] - artboard.artboardRect[1];
    var newYPosition = artboard.artboardRect[1] + artboardHeight - 30;
    var artboardCenterX = (artboard.artboardRect[0] + artboard.artboardRect[2]) / 2;

    for (var i = 0; i < simboliLayer.pageItems.length; i++) {
        var currentItem = simboliLayer.pageItems[i];
        
        if (currentItem.typename === "SymbolItem" && currentItem.symbol.name === SYMBOL_NAMES.TABELA) {
            currentItem.position = [artboardCenterX - (currentItem.width / 2), newYPosition];
        }
    }
}

// Pozicioniranje simbola INFO (iz 06_pozicija_simbola_info.jsx)
function positionInfoSymbol(doc, simboliLayer) {
    var artboard = doc.artboards[0];
    var artboardWidth = artboard.artboardRect[2] - artboard.artboardRect[0];
    var artboardHeight = artboard.artboardRect[3] - artboard.artboardRect[1];
    var newXPosition = artboard.artboardRect[2] + 170;
    var documentWidth = doc.width;
    var documentHeight = doc.height;
    var documentCenterY = documentHeight / 2;

    // Prvo pozicioniranje
    for (var i = 0; i < simboliLayer.pageItems.length; i++) {
        var currentItem = simboliLayer.pageItems[i];
        
        if (currentItem.typename === "SymbolItem" && currentItem.symbol.name === SYMBOL_NAMES.INFO) {
            currentItem.position = [newXPosition - (currentItem.width / 2), documentCenterY - (currentItem.height / 2)];
        }
    }
    
    // Drugi korak - selektuj i pomeri za 250px
    for (var i = 0; i < simboliLayer.pageItems.length; i++) {
        var currentItem = simboliLayer.pageItems[i];
        
        if (currentItem.typename === "SymbolItem" && currentItem.symbol.name === SYMBOL_NAMES.INFO) {
            currentItem.selected = true;
            break;
        }
    }
    
    if (doc.selection.length > 0) {
        for (var i = 0; i < doc.selection.length; i++) {
            var selectedItem = doc.selection[i];
            selectedItem.position = [selectedItem.position[0], selectedItem.position[1] - 250];
        }
    }
}

// Razbijanje simbola TABELA (iz 07_razbijanje_simbola_tabela.jsx)
function breakTabelaSymbol(simboliLayer) {
    for (var i = 0; i < simboliLayer.pageItems.length; i++) {
        var currentItem = simboliLayer.pageItems[i];
        
        if (currentItem.typename === "SymbolItem" && currentItem.symbol.name === SYMBOL_NAMES.TABELA) {
            currentItem.breakLink();
        }
    }
}

// Premeštanje sloja TABELA (iz 08_glavni_sloj_tabela.jsx)
function moveTabelaLayer(doc) {
    try {
        var simboliLayer = doc.layers.getByName(LAYER_NAMES.SIMBOLI);
        var moveTABELALayer = simboliLayer.layers.getByName(LAYER_NAMES.TABELA);
        moveTABELALayer.move(doc, ElementPlacement.PLACEATBEGINNING);
    } catch (e) {
        // Sloj možda ne postoji
    }
}

// Razbijanje simbola INFO (iz 09_razbijanje_simbola_info.jsx)
function breakInfoSymbol(simboliLayer) {
    for (var i = 0; i < simboliLayer.pageItems.length; i++) {
        var currentItem = simboliLayer.pageItems[i];
        
        if (currentItem.typename === "SymbolItem" && currentItem.symbol.name === SYMBOL_NAMES.INFO) {
            currentItem.breakLink();
        }
    }
}

// Premeštanje sloja INFO i isključi štampu (iz 10_glavni_sloj_info.jsx)
function moveInfoLayer(doc) {
    try {
        var simboliLayer = doc.layers.getByName(LAYER_NAMES.SIMBOLI);
        var infoLayer = simboliLayer.layers.getByName(LAYER_NAMES.INFO);
        infoLayer.move(doc, ElementPlacement.PLACEATBEGINNING);
        infoLayer.printable = false;
    } catch (e) {
        // Sloj možda ne postoji
    }
}

// Brisanje sloja "Simboli" (iz 11_brisanje_lejera_simboli.jsx)
function deleteSimboliLayer(doc) {
    try {
        var simbolLayer = doc.layers.getByName(LAYER_NAMES.SIMBOLI);
        simbolLayer.remove();
    } catch (e) {
        // Sloj možda ne postoji
    }
}

// Pokretanje glavne funkcije
main();
