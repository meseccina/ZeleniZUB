#target illustrator

// Funkcija za generisanje slučajnih vrednosti za CMYK boje
function getRandomCmykValue(maxValue) {
    return Math.floor(Math.random() * (maxValue + 1)); // Vrednosti od 0 do maxValue
}

// Funkcija za generisanje random boje sa novim uslovom za boje preko 50%
function generateRandomColor(previousColor) {
    var randomCyan, randomMagenta, randomYellow, randomBlack;

    // Ako prethodna boja postoji, pravimo komplementarnu
    if (previousColor) {
        // Komplementarne vrednosti za Cyan, Magenta, Yellow
        randomCyan = 100 - previousColor.cyan;    // Oduzimanje od 100 daje komplementarnu vrednost
        randomMagenta = 100 - previousColor.magenta;
        randomYellow = 100 - previousColor.yellow;
    } else {
        // Prva boja, generišemo nasumično
        randomCyan = getRandomCmykValue(100);
        randomMagenta = getRandomCmykValue(25);
        randomYellow = getRandomCmykValue(100);
    }

    // Generišemo random vrednost za Black (K) između 0 i 15
    randomBlack = getRandomCmykValue(15);

    return {
        cyan: randomCyan,
        magenta: randomMagenta,
        yellow: randomYellow,
        black: randomBlack
    };
}

// Funkcija za selektovanje pravougaonika unutar grupa
function selectRectanglesInGroup(group) {
    var selectedCount = 0;

    // Iteriraj kroz sve objekte unutar grupe
    for (var i = 0; i < group.pageItems.length; i++) {
        var item = group.pageItems[i];

        // Proveri da li objekat nije tekstualni okvir i da je pravougaonik
        if (item.typename !== "TextFrame" && item.typename === "PathItem" && item.closed) {
            item.selected = true;
            selectedCount++;
        }
    }

    return selectedCount;
}

// Pronađi sloj "ZA MONTAZU"
var montageLayer = app.activeDocument.layers["ZA MONTAZU"];

if (montageLayer) {
    // Čistimo trenutnu selekciju
    app.activeDocument.selection = null;
    
    // Selektujemo sve objekte u sloju
    var items = montageLayer.pageItems;
    var selectedCount = 0; // Brojač selektovanih objekata

    // Iteriraj kroz sve objekte u sloju
    for (var i = 0; i < items.length; i++) {
        // Ako je objekat grupa, proveri pravougaonike unutar nje
        if (items[i].typename === "GroupItem") {
            selectedCount += selectRectanglesInGroup(items[i]);
        } else if (items[i].typename === "PathItem" && items[i].closed) {
            // Ako nije grupa, ali je pravougaonik, selektuj ga
            items[i].selected = true;
            selectedCount++;
        }
    }

    // Ako nema selektovanih objekata, obavesti korisnika
    if (selectedCount === 0) {
        alert("Nema pravougaonika za selektovanje u sloju 'ZA MONTAZU'.");
    }

    // Generiši prvu random boju (početnu boju)
    var previousColor = null;  // Početno nemamo prethodnu boju
    var randomColor = generateRandomColor(previousColor);

    // Proveri da li su objekti selektovani
    if (app.activeDocument.selection.length > 0) {
        // Iteriraj kroz selektovane objekte
        for (var i = 0; i < app.activeDocument.selection.length; i++) {
            var item = app.activeDocument.selection[i];

            // Postavi Fill na random boju (CMYK)
            item.fillColor = new CMYKColor();
            item.fillColor.cyan = randomColor.cyan;
            item.fillColor.magenta = randomColor.magenta;
            item.fillColor.yellow = randomColor.yellow;
            item.fillColor.black = randomColor.black;

            // Proveri da li objekat ima stroke i postavi ga na crno (CMYK)
            if (item.stroked) {
                item.strokeColor = new CMYKColor();
                item.strokeColor.cyan = 0;
                item.strokeColor.magenta = 0;
                item.strokeColor.yellow = 0;
                item.strokeColor.black = 100;
            } else {
                // Ako nema stroke, postavi stroked na true
                item.stroked = true;
                item.strokeColor = new CMYKColor();
                item.strokeColor.cyan = 0;
                item.strokeColor.magenta = 0;
                item.strokeColor.yellow = 0;
                item.strokeColor.black = 100;
            }

            // Postavi debljinu Stroke-a (opciono)
            item.strokeWidth = 1; // Možeš promeniti vrednost
        }

        // Generiši sledeću komplementarnu boju
        previousColor = randomColor; // Sada postavljamo prethodnu boju kao osnovu za sledeću
        randomColor = generateRandomColor(previousColor); // Generišemo sledeću boju
    } else {
        alert("Nema selektovanih objekata.");
    }
} else {
    alert("Sloj 'ZA MONTAZU' nije pronađen.");
}
