#target illustrator

(function() {
    if (app.documents.length === 0) {
        alert("Nema otvorenih dokumenata!");
        return;
    }

    var doc = app.activeDocument;
    var sel = doc.selection;

    if (sel.length !== 1) {
        alert("Selektuj jedan tekstualni objekat!");
        return;
    }

    var obj = sel[0];

    if (obj.typename !== "TextFrame") {
        alert("Selektovani objekat nije tekst!");
        return;
    }

    try {
        var fontName = obj.textRange.characterAttributes.textFont.name;

        // ScriptUI prozor sa tekst poljem koje možeš kopirati
        var w = new Window("dialog", "Font selektovanog teksta");
        w.orientation = "column";
        w.alignChildren = ["fill", "top"];

        var txt = w.add("edittext", undefined, fontName, {multiline:false});
        txt.characters = 50;
        txt.active = true; // automatski selektuje tekst

        var btn = w.add("button", undefined, "OK");

        w.show();

    } catch(e) {
        alert("Ne mogu da pročitam font selektovanog teksta. Možda je tekst pretvoren u oblike (outlines).");
    }
})();
