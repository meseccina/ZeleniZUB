#target illustrator

if (app.documents.length === 0) {
    alert("Nema otvorenog dokumenta.");
    exit();
}

var doc = app.activeDocument;

// 6.2 mm → pt
var reduceMM = 6.2;
var reducePt = reduceMM * 2.834645669;

// Selektuj sve
doc.selection = null;
app.executeMenuCommand("selectall");

var sel = doc.selection;
if (sel.length === 0) {
    alert("Nema objekata.");
    exit();
}

// Izračunaj ukupne granice selekcije
var left = Infinity;
var top = -Infinity;
var right = -Infinity;
var bottom = Infinity;

for (var i = 0; i < sel.length; i++) {
    var b = sel[i].geometricBounds;
    left   = Math.min(left,   b[0]);
    top    = Math.max(top,    b[1]);
    right  = Math.max(right,  b[2]);
    bottom = Math.min(bottom, b[3]);
}

var totalHeight = top - bottom;
var newHeight = totalHeight - reducePt;

if (newHeight <= 0) {
    alert("Smanjenje je veće od visine selekcije.");
    exit();
}

var scaleY = (newHeight / totalHeight) * 100;

// Centar cele selekcije
var centerY = (top + bottom) / 2;

// Skaliraj svaki objekat u odnosu na zajednički centar
for (var i = 0; i < sel.length; i++) {
    var obj = sel[i];
    var b = obj.geometricBounds;
    var objCenterY = (b[1] + b[3]) / 2;

    // Pomeri objekat relativno prema centru selekcije
    var dy = (objCenterY - centerY) * (scaleY / 100 - 1);

    obj.resize(
        100,            // X
        scaleY,         // Y
        true,
        true,
        true,
        true,
        scaleY,
        Transformation.CENTER
    );

    obj.translate(0, dy);
}

alert("Sve je smanjeno za 6.2 mm kao jedna celina.");

