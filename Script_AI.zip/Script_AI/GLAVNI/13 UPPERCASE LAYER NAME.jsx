#target illustrator

(function () {
    if (app.documents.length === 0) {
        alert("Nijedan dokument nije otvoren.");
        return;
    }

    var doc = app.activeDocument;
    var layers = doc.layers;
    var changed = 0;

    for (var i = 0; i < layers.length; i++) {
        var lyr = layers[i];

        // preskoči zaključane slojeve
        if (lyr.locked) continue;

        var oldName = lyr.name;
        var newName = oldName.toUpperCase();

        if (oldName !== newName) {
            lyr.name = newName;
            changed++;
        }
    }

    alert("Gotovo!\nPromenjeno imena slojeva: " + changed);
})();
