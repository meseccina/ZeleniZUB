#target illustrator

(function () {

    if (app.documents.length === 0) {
        alert("Nema otvorenog dokumenta.");
        return;
    }

    var doc = app.activeDocument;
    var output = [];

    // --------------------------------------------------
    // Helper: indent
    // --------------------------------------------------
    function indent(level) {
        var s = "";
        for (var i = 0; i < level; i++) s += "    ";
        return s;
    }

    // --------------------------------------------------
    // Ime objekta
    // --------------------------------------------------
    function getItemName(item) {
        try {
            if (item.name && item.name !== "") {
                return '"' + item.name + '"';
            }
        } catch (e) {}
        return "[NO NAME]";
    }

    // --------------------------------------------------
    // Opis objekta
    // --------------------------------------------------
    function describeItem(item) {
        var desc = item.typename + " " + getItemName(item);

        if (item.typename === "PathItem") {
            desc += item.clipping ? " (CLIPPING MASK)" : " (Path)";
        }

        if (item.typename === "GroupItem") {
            desc += item.clipped ? " (CLIPPED GROUP)" : " (Group)";
        }

        if (item.typename === "CompoundPathItem") {
            desc += " (Compound Path)";
        }

        if (item.typename === "TextFrame") {
            desc += " (Text)";
        }

        if (item.typename === "SymbolItem") {
            desc += " (Symbol Instance)";
        }

        if (item.locked) desc += " [LOCKED]";

        return desc;
    }

    // --------------------------------------------------
    // Rekurzivni prolaz
    // --------------------------------------------------
    function scanItem(item, level) {
        output.push(indent(level) + "- " + describeItem(item));

        if (item.typename === "GroupItem") {
            for (var i = 0; i < item.pageItems.length; i++) {
                scanItem(item.pageItems[i], level + 1);
            }
        }

        if (item.typename === "CompoundPathItem") {
            for (var j = 0; j < item.pathItems.length; j++) {
                scanItem(item.pathItems[j], level + 1);
            }
        }
    }

    // --------------------------------------------------
    // Slojevi
    // --------------------------------------------------
    for (var l = 0; l < doc.layers.length; l++) {
        var layer = doc.layers[l];

        output.push("");
        output.push(
            "LAYER: " + layer.name +
            (layer.locked ? " [LOCKED]" : "")
        );

        for (var i = 0; i < layer.pageItems.length; i++) {
            scanItem(layer.pageItems[i], 1);
        }
    }

    // --------------------------------------------------
    // UI
    // --------------------------------------------------
    var w = new Window("dialog", "Lista svih objekata (bez HIDDEN)");
    w.orientation = "column";
    w.alignChildren = "fill";

    var txt = w.add("edittext", undefined, output.join("\n"), {
        multiline: true,
        scrolling: true
    });
    txt.minimumSize.height = 500;
    txt.minimumSize.width = 750;

    w.add("button", undefined, "Zatvori");

    w.show();

})();
