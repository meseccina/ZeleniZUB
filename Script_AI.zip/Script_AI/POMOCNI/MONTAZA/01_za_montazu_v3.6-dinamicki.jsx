// 01_za_montazu_v3.6 - DINAMIČKA VERZIJA (kreira samo onoliko pravougaonika koliko ima boja)
// Konstanta za konverziju iz milimetara u tačke
var MM_TO_POINTS = 2.834645669; // Tačnija vrednost

// Funkcija za proveru i kreiranje sloja "ZA MONTAZU"
function createMontageLayerIfNotExists(doc) {
    var layerExists = false;
    // Prolazimo kroz sve slojeve da proverimo da li sloj "ZA MONTAZU" već postoji
    for (var i = 0; i < doc.layers.length; i++) {
        if (doc.layers[i].name === "ZA MONTAZU") {
            layerExists = true;
            break;
        }
    }

    // Ako sloj "ZA MONTAZU" ne postoji, kreiramo ga
    if (!layerExists) {
        var newLayer = doc.layers.add();
        newLayer.name = "ZA MONTAZU"; // Dajemo sloju ime
        newLayer.printable = false; // Sloj nije printabilan
        newLayer.locked = false;    // Sloj nije zaključan
        newLayer.visible = true;    // Sloj je vidljiv
        doc.activeLayer = newLayer; // Postavljamo sloj kao aktivan
    }
    
    return doc.layers["ZA MONTAZU"];
}

// Funkcija za kreiranje pravougaonika sa zaokruženim dimenzijama
function createRectangle(doc, x, y, width, height) {
    var roundedWidth = Math.ceil(width);
    var roundedHeight = Math.ceil(height);
    var rectangle = doc.pathItems.rectangle(y * MM_TO_POINTS, x * MM_TO_POINTS, roundedWidth * MM_TO_POINTS, roundedHeight * MM_TO_POINTS);

    rectangle.filled = false;
    rectangle.strokeWidth = 0.5;
    rectangle.stroked = true;
    rectangle.strokeColor = new CMYKColor();
    rectangle.strokeColor.cyan = 0;
    rectangle.strokeColor.magenta = 0;
    rectangle.strokeColor.yellow = 0;
    rectangle.strokeColor.black = 100;

    return rectangle;
}

// Funkcija za postavljanje položaja pravougaonika
function setPosition(rectangle, x, y) {
    rectangle.position = [x * MM_TO_POINTS, y * MM_TO_POINTS];
}

// Funkcija za dobijanje dimenzija artboarda
function getArtboardDimensions(doc) {
    var artboard = doc.artboards[0];
    var artboardRect = artboard.artboardRect;
    var width = (artboardRect[2] - artboardRect[0]) / MM_TO_POINTS;
    var height = (artboardRect[1] - artboardRect[3]) / MM_TO_POINTS;
    return [width, height]; // Vraća niz kao u staroj verziji
}

// Funkcija za čitanje procesnih boja
function readProcessColors(doc) {
    try {
        var moveTableLayer = doc.layers["MOVE TABELA 26"];
        if (!moveTableLayer) return null;
        
        var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
        if (!bojeGroup) return null;
        
        var processGroup = bojeGroup.groupItems["PROCESNE BOJE"];
        if (!processGroup) return null;
        
        var existingColors = {
            cyan: false,
            magenta: false,
            yellow: false,
            black: false
        };
        
        // Proveri path objekte
        for (var i = 0; i < processGroup.pageItems.length; i++) {
            var item = processGroup.pageItems[i];
            if (item.name === "Cyan") existingColors.cyan = true;
            if (item.name === "Magenta") existingColors.magenta = true;
            if (item.name === "Yellow") existingColors.yellow = true;
            if (item.name === "Black") existingColors.black = true;
        }
        
        return existingColors;
        
    } catch (e) {
        return null;
    }
}

// Funkcija za čitanje spot boja
function readSpotColors(doc) {
    try {
        var moveTableLayer = doc.layers["MOVE TABELA 26"];
        if (!moveTableLayer) return [];
        
        var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
        if (!bojeGroup) return [];
        
        var spotGroup = bojeGroup.groupItems["SPOT BOJE"];
        if (!spotGroup) return [];
        
        var spotColors = [];
        
        // Čitaj iz text.b_01, text.b_02, text.b_03
        for (var j = 1; j <= 3; j++) {
            try {
                var textItem = spotGroup.textFrames.getByName("text.b_0" + j);
                var colorName = textItem.contents;
                var colorString = String(colorName);
                
                if (colorString && colorString !== "") {
                    spotColors.push(colorString);
                }
            } catch (e) {
                // Text frame ne postoji, preskačemo
            }
        }
        
        return spotColors;
        
    } catch (e) {
        return [];
    }
}

// Funkcija za kombinovanje svih boja u pravom redosledu
function getAllColors(doc) {
    var allColors = [];
    
    // Procesne boje
    var processColors = readProcessColors(doc);
    if (processColors) {
        if (processColors.cyan) allColors.push("C");
        if (processColors.magenta) allColors.push("M");
        if (processColors.yellow) allColors.push("Y");
        if (processColors.black) allColors.push("K");
    }
    
    // Spot boje
    var spotColors = readSpotColors(doc);
    for (var i = 0; i < spotColors.length; i++) {
        allColors.push(spotColors[i]);
    }
    
    // Bela boja (uvek fiksna)
    allColors.push("BELA");
    
    return allColors;
}

// Funkcija za čitanje broja boja
function getColorCount(doc) {
    try {
        var allColors = getAllColors(doc);
        return Math.min(allColors.length, 8);
    } catch (e) {
        return 8;
    }
}

// Glavna funkcija
function createMontageRectangles() {
    var doc = app.activeDocument;
    
    // Proveri da li postoji MOVE TABELA 26
    var moveTableLayer = null;
    try {
        moveTableLayer = doc.layers["MOVE TABELA 26"];
    } catch (e) {
        // Sloj ne postoji
    }
    
    if (!moveTableLayer) {
        var colorCount = 8;
    } else {
        var colorCount = getColorCount(doc);
    }
    
    // Kreiraj sloj ako ne postoji
    var montageLayer = createMontageLayerIfNotExists(doc);
    
    // Obriši postojeće pravougaonike ako postoje
    try {
        for (var i = 1; i <= 8; i++) {
            var rectName = (i < 10 ? "0" + i : i);
            try {
                var existingRect = montageLayer.pageItems.getByName(rectName);
                existingRect.remove();
            } catch (e) {
                // Ne postoji, preskačemo
            }
        }
    } catch (e) {
        // Greška pri brisanju, ignorišimo
    }
    
    // Dimenzije pravougaonika (kao u staroj verziji)
    var artboardDimensions = getArtboardDimensions(doc);
    var artboardWidth = artboardDimensions[0]; // Niz, ne objekat
    var artboardHeight = artboardDimensions[1]; // Niz, ne objekat
    
    var rectWidth = artboardWidth / 10;
    var rectHeight = artboardHeight / 10;
    var spacing = 0; // Nema spacing u staroj verziji
    var columns = 4;
    var rows = Math.ceil(colorCount / columns);

    // Ukupna širina i visina mreže
    var totalWidth = columns * rectWidth + (columns - 1) * spacing;
    var totalHeight = rows * rectHeight + (rows - 1) * spacing;

    // Pozicioniranje kao u staroj verziji
    var currentX = 0;
    var currentY = 0;
    var maxRectanglesPerRow = 4;
    var rectangleMargin = 0;

    // Kreiraj pravougaonike samo za broj boja
    for (var i = 0; i < colorCount; i++) {
        try {
            var rectangle = createRectangle(doc, currentX, currentY, rectWidth, rectHeight);
            var rectName = (i + 1 < 10 ? "0" + (i + 1) : (i + 1));
            rectangle.name = rectName;
            
            // Postavi pravougaonik u sloj
            rectangle.move(montageLayer);
            
            // Pomeri za sledeći
            currentX += (rectWidth + rectangleMargin);
            
            if (i % maxRectanglesPerRow === maxRectanglesPerRow - 1) {
                currentX = 0;
                currentY -= (rectHeight + rectangleMargin);
            }
        } catch (e) {
            // Greška pri kreiranju pravougaonika, preskačemo
        }
    }
}

// Pokreni glavnu funkciju
createMontageRectangles();
