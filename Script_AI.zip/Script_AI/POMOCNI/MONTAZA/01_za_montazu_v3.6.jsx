// 01_za_montazu_v3.6 - DINAMIČKA VERZIJA (kreira samo onoliko pravougaonika koliko ima boja)
// Konstanta za konverziju iz milimetara u tačke
var MM_TO_POINTS = 2.834645669; // Tačnija vrednost

// Funkcija za proveru i kreiranje sloja "ZA MONTAZU"
function createMontageLayerIfNotExists(doc) {
    var layerExists = false;
    // Prolazimo kroz sve slojeve da proverimo da li sloj "ZA MONTAZU" već postoji
    for (var i = 0; i < doc.layers.length; i++) {
        if (doc.layers[i].name === "ZA MONTAZU") {
            layerExists = true;
            break;
        }
    }

    // Ako sloj "ZA MONTAZU" ne postoji, kreiramo ga
    if (!layerExists) {
        var newLayer = doc.layers.add();
        newLayer.name = "ZA MONTAZU"; // Dajemo sloju ime
        newLayer.printable = false; // Sloj nije printabilan
        newLayer.locked = false;    // Sloj nije zaključan
        newLayer.visible = true;    // Sloj je vidljiv
        doc.activeLayer = newLayer; // Postavljamo sloj kao aktivan
    }
    
    return doc.layers["ZA MONTAZU"];
}

// Funkcija za kreiranje pravougaonika sa tačnim dimenzijama
function createRectangle(doc, x, y, width, height) {
    // Bez zaokruživanja - koristimo tačne vrednosti
    var rectangle = doc.pathItems.rectangle(y * MM_TO_POINTS, x * MM_TO_POINTS, width * MM_TO_POINTS, height * MM_TO_POINTS);

    rectangle.filled = false;
    rectangle.strokeWidth = 0.5;
    rectangle.stroked = true;
    rectangle.strokeColor = new CMYKColor();
    rectangle.strokeColor.cyan = 0;
    rectangle.strokeColor.magenta = 0;
    rectangle.strokeColor.yellow = 0;
    rectangle.strokeColor.black = 100;

    return rectangle;
}

// Funkcija za postavljanje položaja pravougaonika
function setPosition(rectangle, x, y) {
    rectangle.position = [x * MM_TO_POINTS, y * MM_TO_POINTS];
}

// Funkcija za dobijanje dimenzija artboarda
function getArtboardDimensions(doc) {
    var artboard = doc.artboards[0];
    var artboardRect = artboard.artboardRect;
    var width = (artboardRect[2] - artboardRect[0]) / MM_TO_POINTS;
    var height = (artboardRect[1] - artboardRect[3]) / MM_TO_POINTS;
    return [width, height]; // Vraća niz kao u staroj verziji
}

// Funkcija za premestanje pravougaonika u sloj "ZA MONTAZU"
function moveRectanglesToMontageLayer(rectangles, montageLayer) {
    for (var i = 0; i < rectangles.length; i++) {
        rectangles[i].move(montageLayer, ElementPlacement.PLACEATEND);
    }
}

// Funkcija za čitanje procesnih boja
function readProcessColors(doc) {
    try {
        var moveTableLayer = doc.layers["MOVE TABELA 26"];
        if (!moveTableLayer) return null;
        
        var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
        if (!bojeGroup) return null;
        
        var processGroup = bojeGroup.groupItems["PROCESNE BOJE"];
        if (!processGroup) return null;
        
        var existingColors = {
            cyan: false,
            magenta: false,
            yellow: false,
            black: false
        };
        
        for (var i = 0; i < processGroup.pageItems.length; i++) {
            var item = processGroup.pageItems[i];
            if (item.name === "Cyan") existingColors.cyan = true;
            if (item.name === "Magenta") existingColors.magenta = true;
            if (item.name === "Yellow") existingColors.yellow = true;
            if (item.name === "Black") existingColors.black = true;
        }
        
        return existingColors;
    } catch (e) {
        return null;
    }
}

// Funkcija za čitanje spot boja
function readSpotColors(doc) {
    try {
        var moveTableLayer = doc.layers["MOVE TABELA 26"];
        if (!moveTableLayer) return [];
        
        var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
        if (!bojeGroup) return [];
        
        var spotGroup = bojeGroup.groupItems["SPOT BOJE"];
        if (!spotGroup) return [];
        
        var spotColors = [];
        
        for (var j = 1; j <= 3; j++) {
            try {
                var textItem = spotGroup.textFrames.getByName("text.b_0" + j);
                var colorName = textItem.contents;
                var colorString = String(colorName);
                
                if (colorString && colorString !== "" && !/^P[A-Z]+C$/i.test(colorString)) {
                    spotColors.push(colorString);
                }
            } catch (e) {
                // Text frame ne postoji, preskačemo
            }
        }
        
        return spotColors;
    } catch (e) {
        return [];
    }
}

// Funkcija za čitanje svih boja iz swatches-a
function readAllSwatchColors(doc) {
    var allSwatchColors = [];
    
    // Crna lista boja koje se ne broju
    var blacklistedColors = [
        "[None]", "[Registration]", "White", "Black",
        "CutContour", "Varnish", "SpotUV", "Metallic",
        "Gold", "Silver", "Bronze", "Copper",
        "TRANSPARENT", "Rasklop"
    ];
    
    try {
        // Prođi kroz sve swatches
        for (var i = 0; i < doc.swatches.length; i++) {
            var swatch = doc.swatches[i];
            var colorName = swatch.name;
            
            // Proveri da li je boja na crnoj listi
            var isBlacklisted = false;
            for (var j = 0; j < blacklistedColors.length; j++) {
                if (colorName === blacklistedColors[j]) {
                    isBlacklisted = true;
                    break;
                }
            }
            
            // Dodaj boju ako nije na crnoj listi i nije prazna
            if (!isBlacklisted && colorName && colorName !== "") {
                allSwatchColors.push(colorName);
            }
        }
        
    } catch (e) {
        // Greška pri čitanju swatches-a
    }
    
    return allSwatchColors;
}

// Funkcija za kombinovanje svih boja u pravom redosledu
function getAllColors(doc) {
    var allColors = [];
    
    // Procesne boje
    var processColors = readProcessColors(doc);
    if (processColors) {
        if (processColors.cyan) allColors.push("C");
        if (processColors.magenta) allColors.push("M");
        if (processColors.yellow) allColors.push("Y");
        if (processColors.black) allColors.push("K");
    }
    
    // Spot boje iz swatches-a (nova funkcija)
    var swatchColors = readAllSwatchColors(doc);
    for (var i = 0; i < swatchColors.length; i++) {
        allColors.push(swatchColors[i]);
    }
    
    return allColors;
}

// Funkcija za kreiranje pravougaonika i organizovanje na artboard-u
function arrangeRectangles(doc) {
    // Dobavi broj boja
    var allColors = getAllColors(doc);
    var numRectangles = Math.min(allColors.length, 12); // Maksimalno 12
    
    alert("Pronađeno " + numRectangles + " boja.");
    
    var artboardDimensions = getArtboardDimensions(doc);
    var artboardWidth = artboardDimensions[0];
    var artboardHeight = artboardDimensions[1];
    
    var maxRectanglesPerRow = 4;
    var rectangleMargin = 0;
    
    var rectangleWidth = Math.abs((artboardWidth / 10) % 1) < 0.0001 ? artboardWidth / 10 : Math.ceil(artboardWidth / 10);
    var rectangleHeight = Math.abs((artboardHeight / 10) % 1) < 0.0001 ? artboardHeight / 10 : Math.ceil(artboardHeight / 10);
    
    var currentX = 0;
    var currentY = 0;
    
    var rectangles = [];
    
    // Kreiraj pravougaonike
    for (var i = 0; i < numRectangles; i++) {
        var rectangle = createRectangle(doc, currentX, currentY, rectangleWidth, rectangleHeight);
        setPosition(rectangle, currentX, currentY);

        rectangles.push(rectangle);
        
        currentX += (rectangleWidth + rectangleMargin);
        
        if (i % maxRectanglesPerRow === maxRectanglesPerRow - 1) {
            currentX = 0;
            currentY -= (rectangleHeight + rectangleMargin);
        }
    }
    
    // Premestanje svih pravougaonika u sloj "ZA MONTAZU"
    var montageLayer = doc.layers["ZA MONTAZU"];
    moveRectanglesToMontageLayer(rectangles, montageLayer);

    // Preimenovanje pravougaonika u sloju
    renameRectangles(montageLayer);
}

// Funkcija za preimenovanje pravougaonika u sloju
function renameRectangles(layer) {
    var rectangles = findRectangles(layer);
    if (rectangles.length > 0) {
        for (var i = 0; i < rectangles.length; i++) {
            rectangles[i].name = pad(i + 1, 2); // Preimenovanje sa dodatkom nula
        }
    } else {
        alert("U sloju 'ZA MONTAZU' nema pravougaonika.");
    }
}

// Nalazi sve pravougaonike u sloju
function findRectangles(layer) {
    var rectangles = [];
    for (var i = 0; i < layer.pageItems.length; i++) {
        var item = layer.pageItems[i];
        if (item.typename === "PathItem") {
            rectangles.push(item);
        }
    }
    return rectangles;
}

// Funkcija za dodavanje nula ispred broja
function pad(num, size) {
    var s = num.toString();
    while (s.length < size) s = "0" + s;
    return s;
}

// Pozivanje funkcije za proveru i kreiranje sloja "ZA MONTAZU"
createMontageLayerIfNotExists(app.activeDocument);

// Pozivanje funkcije za kreiranje pravougaonika sa dinamičkim brojem
arrangeRectangles(app.activeDocument);
