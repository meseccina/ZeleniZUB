//@target illustrator

// Optimizovana verzija 02_pun_naziv_za_montazu v2.0.jsx sa keširanjem

(function() {
    try {
        if (app.documents.length === 0) {
            alert("Nema otvorenog dokumenta.");
            return;
        }

        var doc = app.activeDocument;
        var filePath = doc.fullName.fsName;
        var fileName = doc.name;

        // Provera da li je MOVE ili Chips WAY putanja
        var isMovePath = filePath.indexOf("\\MOVE\\") !== -1 || filePath.indexOf("\\MOVE/") !== -1;
        var isChipsWayPath = filePath.indexOf("\\Chips WAY\\") !== -1 || filePath.indexOf("\\Chips WAY/") !== -1;
        
        var firstPart = "", secondPart = "", thirdPart = "", fourthPart = "", fifthPart = "";
        
        if (isMovePath) {
            // Logika za MOVE
            var pathParts = filePath.split(/[\/\\]/);
            var moveIndex = -1;
            
            // Pronađi MOVE u putanji
            for (var i = 0; i < pathParts.length; i++) {
                if (pathParts[i] === "MOVE") {
                    moveIndex = i;
                    break;
                }
            }
            
            if (moveIndex !== -1) {
                firstPart = "MOVE";
                // secondPart je sledeći folder posle MOVE (ako postoji)
                if (moveIndex + 1 < pathParts.length) {
                    secondPart = pathParts[moveIndex + 1];
                }
            }
            
            // Ostali delovi iz imena fajla
            var fileParts = fileName.split(" - ");
            thirdPart = fileParts[0] || "";
            fourthPart = fileParts[1] || "";
            fifthPart = fileParts[2] || "";
            
        } else if (isChipsWayPath) {
            // Logika za Chips WAY
            firstPart = "Chips WAY";
            
            // Svi ostali delovi iz imena fajla
            var fileParts = fileName.split(" - ");
            secondPart = fileParts[0] || "";
            thirdPart = fileParts[1] || "";
            fourthPart = fileParts[2] || "";
            
        } else {
            // Fallback na staru logiku ako nije nijedan od navedenih
            var fileParts = fileName.split(" - ");
            firstPart = fileParts[0] || "";
            secondPart = fileParts[1] || "";
            thirdPart = fileParts[2] || "";
        }

        var textContent = firstPart;
        if (secondPart) textContent += "\r" + secondPart;
        if (thirdPart) textContent += "\r" + thirdPart;
        if (fourthPart) textContent += "\r" + fourthPart;
        if (fifthPart) textContent += "\r" + fifthPart;
        textContent += "\r\rC";

        var textFrame = doc.textFrames.add();
        textFrame.contents = textContent;

        // Keširanje fonta i drugih reference
        try {
            var myFont = app.textFonts.getByName("ArialNarrow-Bold");
            textFrame.textRange.characterAttributes.textFont = myFont;
        } catch (e) {
            // Font ne postoji, koristi default
        }

        textFrame.textRange.characterAttributes.size = 10;

        try {
            textFrame.textRange.paragraphAttributes.justification = Justification.CENTER;
        } catch (e) {
            // Greška pri centriranju, ignorišemo
        }
        
        // Automatsko smanjivanje fonta ako je tekst predugačak
        function adjustFontSizeToFit(textFrame, maxRectangleWidth, maxRectangleHeight) {
            var originalSize = textFrame.textRange.characterAttributes.size;
            var minSize = 4; // Minimalna veličina fonta
            var currentSize = originalSize;
            
            // 1mm margina = 2.83465 tačaka
            var margin = 2.83465;
            var maxWidth = maxRectangleWidth - (2 * margin);
            var maxHeight = maxRectangleHeight - (2 * margin);
            
            while (currentSize > minSize) {
                textFrame.textRange.characterAttributes.size = currentSize;
                
                // Proveri da li tekst staje
                var lines = textFrame.lines;
                var fits = true;
                
                // Proveri ukupnu visinu teksta
                var totalHeight = 0;
                for (var i = 0; i < lines.length; i++) {
                    totalHeight += lines[i].height;
                    // Proveri da li svaka linija staje u širinu
                    if (lines[i].width > maxWidth) {
                        fits = false;
                        break;
                    }
                }
                
                // Proveri da li ukupna visina staje
                if (totalHeight > maxHeight) {
                    fits = false;
                }
                
                if (fits) {
                    break;
                }
                
                currentSize -= 0.5; // Smanji za pola poena
            }
            
            return currentSize;
        }
        
        // Dobijanje dimenzija pravougaonika iz artboarda
        function getRectangleDimensions(doc) {
            var artboard = doc.artboards[0];
            var artboardWidth = (artboard.artboardRect[2] - artboard.artboardRect[0]);
            var artboardHeight = (artboard.artboardRect[1] - artboard.artboardRect[3]);
            
            var rectangleWidth = artboardWidth / 10;
            var rectangleHeight = artboardHeight / 10;
            
            return [rectangleWidth, rectangleHeight];
        }
        
        // Proveri dužinu teksta i prilagodi font
        var rectDimensions = getRectangleDimensions(doc);
        var maxRectangleWidth = rectDimensions[0];
        var maxRectangleHeight = rectDimensions[1];
        
        if (isChipsWayPath && thirdPart && thirdPart.length > 25) {
            // Za CHIPS WAY - proveri thirdPart
            adjustFontSizeToFit(textFrame, maxRectangleWidth, maxRectangleHeight);
        } else if (isMovePath && fourthPart && fourthPart.length > 25) {
            // Za MOVE - proveri fourthPart
            adjustFontSizeToFit(textFrame, maxRectangleWidth, maxRectangleHeight);
        }

        textFrame.top = doc.height - 50;
        textFrame.left = 100;
        textFrame.selected = true;

    } catch (e) {
        alert("Greška u optimizovanoj skripti: " + e.message);
    }
})();
