//@target illustrator

// Optimizovana verzija 03_dupliciranje_teksta_za_montazu.jsx sa keširanjem

(function() {
    var doc = app.activeDocument;
    var layerName = "ZA MONTAZU";
    var rectNames = ["01", "02", "03", "04", "05", "06", "07", "08"];

    // Keširanje reference na sloj
    var targetLayer = null;
    try {
        targetLayer = doc.layers.getByName(layerName);
    } catch (e) {
        alert("Sloj '" + layerName + "' ne postoji.");
        return;
    }

    // Keširanje svih pageItems za bržu pretragu
    var allPageItems = targetLayer.pageItems;
    var textItem = null;
    
    // Optimizovana pretraga prvog tekstualnog objekta
    for (var i = 0; i < allPageItems.length; i++) {
        if (allPageItems[i].typename === "TextFrame") {
            textItem = allPageItems[i];
            break;
        }
    }

    if (!textItem) {
    // Kreiraj novi tekstualni objekat ako ne postoji
    textItem = targetLayer.textFrames.add();
    textItem.name = "brisi me";
    textItem.contents = "C"; // Postavi početni sadržaj
    textItem.top = 100;
    textItem.left = 100;
}

    // Preimenovanje originalnog tekstualnog objekta
    textItem.name = "brisi me";

    // Keširanje pravougaonika za brži pristup
    var rectanglesMap = {};
    for (var k = 0; k < allPageItems.length; k++) {
        var item = allPageItems[k];
        // Manualna provera umesto .indexOf()
        var isRectName = false;
        for (var m = 0; m < rectNames.length; m++) {
            if (item.name === rectNames[m]) {
                isRectName = true;
                break;
            }
        }
        if (isRectName) {
            rectanglesMap[item.name] = item;
        }
    }

    // Optimizovano dupliciranje
    for (var j = 0; j < rectNames.length; j++) {
        var rectName = rectNames[j];
        var rect = rectanglesMap[rectName];

        if (rect) {
            var newTextItem = textItem.duplicate();
            newTextItem.name = "Tekst " + rectName;

            // Optimizovano pozicioniranje
            var rectCenterX = rect.left + (rect.width / 2);
            var rectCenterY = rect.top - (rect.height / 2);

            newTextItem.left = rectCenterX - (newTextItem.width / 2);
            newTextItem.top = rectCenterY + (newTextItem.height / 2);
        }
    }

})();
