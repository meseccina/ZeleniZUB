//@target illustrator

(function() {
    var doc = app.activeDocument;
    var layerName = "ZA MONTAZU";
    var targetName = "brisi me";
    var targetLayer = null;

    // Sigurno dohvatimo sloj
    try {
        targetLayer = doc.layers.getByName(layerName);
    } catch (e) {
        alert("Sloj '" + layerName + "' ne postoji.");
        return;
    }

    // Tražimo prvi tekstualni objekat sa imenom targetName
    var itemToDelete = null;
    for (var i = targetLayer.pageItems.length - 1; i >= 0; i--) {
        var item = targetLayer.pageItems[i];
        if (item.name === targetName && item.typename === "TextFrame") {
            itemToDelete = item;
            break;
        }
    }

    if (itemToDelete) {
        itemToDelete.remove();
    } else {
        alert("Objekat '" + targetName + "' nije pronađen u sloju '" + layerName + "'.");
    }
})();
