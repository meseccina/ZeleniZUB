//@target illustrator

// Optimizovana skripta koja kombinuje 05_upisivanje_cmyk.jsx i 08_dodavanje_spot_boja_u_tekst_v.1.1.jsx
// Sa keširanjem referenci na slojeve za brže izvršenje

(function() {
    var doc = app.activeDocument;
    
    // Keširanje referenci na slojeve
    var montageLayer = null;
    var spotSubLayer = null;
    
    // Funkcija za keširanje sloja "ZA MONTAZU"
    function getMontageLayer() {
        if (!montageLayer) {
            try {
                montageLayer = doc.layers.getByName("ZA MONTAZU");
            } catch (e) {
                alert("Sloj 'ZA MONTAZU' ne postoji.");
                return null;
            }
        }
        return montageLayer;
    }
    
    // Funkcija za proveru koje procesne boje postoje
    function getExistingProcessColors() {
        try {
            var doc = app.activeDocument;
            var moveTableLayer = doc.layers["MOVE TABELA 26"];
            if (!moveTableLayer) return [];
            
            var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
            if (!bojeGroup) return [];
            
            var processGroup = bojeGroup.groupItems["PROCESNE BOJE"];
            if (!processGroup) return [];
            
            var existingColors = [];
            
            for (var i = 0; i < processGroup.pageItems.length; i++) {
                var item = processGroup.pageItems[i];
                if (item.name === "Cyan") existingColors.push({text: "Tekst 01", color: "C"});
                if (item.name === "Magenta") existingColors.push({text: "Tekst 02", color: "M"});
                if (item.name === "Yellow") existingColors.push({text: "Tekst 03", color: "Y"});
                if (item.name === "Black") existingColors.push({text: "Tekst 04", color: "K"});
            }
            
            return existingColors;
        } catch (e) {
            return [];
        }
    }
    
    // Funkcija za zamenu poslednjeg slova 'C' u tekstu
    function replaceLastCWithChar(textObjectName, replacementChar) {
        var layer = getMontageLayer();
        if (!layer) return false;
        
        try {
            var textItem = layer.textFrames.getByName(textObjectName);
            var content = textItem.contents;
            var lastIndex = content.lastIndexOf("C");
            if (lastIndex !== -1) {
                content = content.substring(0, lastIndex) + replacementChar + content.substring(lastIndex + 1);
                textItem.contents = content;
                return true;
            }
        } catch (e) {
            // Tekstualni objekat ne postoji, preskačemo
        }
        return false;
    }
    
    // Funkcija za dobijanje pravih spot boja iz MOVE TABELA 26
    function getSpotColors() {
        try {
            var doc = app.activeDocument;
            var moveTableLayer = doc.layers["MOVE TABELA 26"];
            if (!moveTableLayer) return [];
            
            var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
            if (!bojeGroup) return [];
            
            var spotGroup = bojeGroup.groupItems["SPOT BOJE"];
            if (!spotGroup) return [];
            
            var spotColors = [];
            
            for (var j = 1; j <= 3; j++) {
                try {
                    var textItem = spotGroup.textFrames.getByName("text.b_0" + j);
                    var colorName = textItem.contents;
                    var colorString = String(colorName);
                    
                    if (colorString && colorString !== "" && !/^P(?!BLACK)[A-Z]+C$/i.test(colorString)) {
                        spotColors.push(colorString);
                    }
                } catch (e) {
                    // Text frame ne postoji, preskačemo
                }
            }
            
            return spotColors;
        } catch (e) {
            return [];
        }
    }
    
    // Funkcija za upisivanje svih boja redom u tekstove
    function writeAllColorsInOrder() {
        var layer = getMontageLayer();
        if (!layer) return;
        
        // Dobavi sve boje redom
        var existingProcessColors = getExistingProcessColors();
        var spotColors = getSpotColors();
        
        // Napravi niz svih boja redom
        var allColors = [];
        for (var i = 0; i < existingProcessColors.length; i++) {
            allColors.push(existingProcessColors[i].color);
        }
        for (var j = 0; j < spotColors.length; j++) {
            allColors.push(spotColors[j]);
        }
        allColors.push("BELA"); // Uvek dodaj BELA na kraju
        
        // Upisi boje redom u tekstove
        for (var k = 0; k < allColors.length && k < 8; k++) {
            var textName = "Tekst " + pad(k + 1, 2);
            
            try {
                var textObj = layer.textFrames.getByName(textName);
                var currentText = textObj.contents;
                
                if (/C$/.test(currentText)) {
                    var updatedText = currentText.replace(/C$/, allColors[k]);
                    textObj.contents = updatedText;
                }
            } catch (e) {
                // Tekst ne postoji, preskačemo
            }
        }
    }
    
    // Funkcija za dodavanje nula ispred broja
    function pad(num, size) {
        var s = num.toString();
        while (s.length < size) s = "0" + s;
        return s;
    }
    
    // Funkcija za dodavanje spot boja u tekstove
    function addSpotColorsToTexts(spotColors) {
        var layer = getMontageLayer();
        if (!layer) return;
        
        // Prvo nađemo koji je sledeći slobodan tekst
        var existingProcessColors = getExistingProcessColors();
        var nextTextIndex = existingProcessColors.length + 1; // +1 jer je 1-based
        
        // Dodaj spot boje počevši od sledećeg slobodnog teksta
        for (var i = 0; i < spotColors.length; i++) {
            var textName = "Tekst " + pad(nextTextIndex + i, 2);
            
            try {
                var textObj = layer.textFrames.getByName(textName);
                var currentText = textObj.contents;
                
                if (/C$/.test(currentText)) {
                    var updatedText = currentText.replace(/C$/, spotColors[i]);
                    textObj.contents = updatedText;
                }
            } catch (e) {
                // Tekst ne postoji, preskačemo
            }
        }
        
        // Dodaj BELA za poslednji tekst
        var lastTextIndex = nextTextIndex + spotColors.length;
        var lastTextName = "Tekst " + pad(lastTextIndex, 2);
        
        try {
            var lastTextObj = layer.textFrames.getByName(lastTextName);
            var lastCurrentText = lastTextObj.contents;
            
            if (/C$/.test(lastCurrentText)) {
                var lastUpdatedText = lastCurrentText.replace(/C$/, "BELA");
                lastTextObj.contents = lastUpdatedText;
            }
        } catch (e) {
            // Tekst ne postoji, preskačemo
        }
    }
    
    // Funkcija za brisanje spot sloja
    function deleteSpotLayer() {
        if (spotSubLayer) {
            try {
                spotSubLayer.remove();
            } catch (e) {
                // Greška pri brisanju, ignorišemo
            }
        }
    }
    
    // Glavna izvršenja
    try {
        // 1) Upisivanje svih boja redom u tekstove
        writeAllColorsInOrder();
        
        // 2) Brisanje spot sloja
        deleteSpotLayer();
        
    } catch (e) {
        alert("Greška u optimizovanoj skripti: " + e.message);
    }
    
})();
