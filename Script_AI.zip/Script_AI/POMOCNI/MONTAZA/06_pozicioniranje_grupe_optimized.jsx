//@target illustrator

// Optimizovana skripta koja pozicionira celu "ZA MONTAZU" grupu 30px ispod artboarda
// Umesto cut/paste operacije

(function() {
    var doc = app.activeDocument;

    // Funkcija za pronalaženje sloja "ZA MONTAZU"
    function getMontageLayer() {
        try {
            return doc.layers.getByName("ZA MONTAZU");
        } catch (e) {
            alert("Sloj 'ZA MONTAZU' ne postoji.");
            return null;
        }
    }

    // Funkcija za bojenje pravougaonika sa istom random svetlom bojom
    function colorRectangles(layer) {
        if (!layer) return;

        // Funkcija za generisanje random boje
        function getRandomCmykValue(maxValue) {
            return Math.floor(Math.random() * (maxValue + 1));
        }

        function generateRandomLightColor() {
            var randomBlack = getRandomCmykValue(15);
            var randomCyan = getRandomCmykValue(100);
            var randomMagenta = getRandomCmykValue(25);
            var randomYellow = getRandomCmykValue(100);

            // Ako bilo koja boja ima vrednost veću od 50%, ostale boje moraju biti u opsegu 0-15%
            if (randomCyan > 50) {
                randomMagenta = getRandomCmykValue(15);
                randomYellow = getRandomCmykValue(15);
            } else if (randomMagenta > 50) {
                randomCyan = getRandomCmykValue(15);
                randomYellow = getRandomCmykValue(15);
            } else if (randomYellow > 50) {
                randomCyan = getRandomCmykValue(15);
                randomMagenta = getRandomCmykValue(15);
            }

            return {
                cyan: randomCyan,
                magenta: randomMagenta,
                yellow: randomYellow,
                black: randomBlack
            };
        }

        // Generiši jednu boju za sve pravougaonike
        var randomColor = generateRandomLightColor();

        // Boji samo pravougaonike (PathItems) sa istom bojom
        for (var i = 0; i < layer.pageItems.length; i++) {
            var item = layer.pageItems[i];
            
            if (item.typename === "PathItem") {
                // Postavi fill na istu random boju
                item.filled = true;
                item.fillColor = new CMYKColor();
                item.fillColor.cyan = randomColor.cyan;
                item.fillColor.magenta = randomColor.magenta;
                item.fillColor.yellow = randomColor.yellow;
                item.fillColor.black = randomColor.black;
                
                // Postavi stroke na crno
                item.stroked = true;
                item.strokeColor = new CMYKColor();
                item.strokeColor.cyan = 0;
                item.strokeColor.magenta = 0;
                item.strokeColor.yellow = 0;
                item.strokeColor.black = 100;
                
                // Postavi debljinu stroke-a
                item.strokeWidth = 1;
            }
        }
    }

    // Funkcija za pozicioniranje sloja ispod artboarda
    function positionLayerBelowArtboard(layer) {
        if (!layer) return;

        // Dobijanje dimenzija aktivnog artboarda
        var activeAB = doc.artboards[doc.artboards.getActiveArtboardIndex()];
        var abBounds = activeAB.artboardRect; // [left, top, right, bottom]

        // Izračunavanje pozicije 300px ispod donjeg dela artboarda
        var targetY = abBounds[3] + 300; // 300px ispod donjeg dela
        var targetX = abBounds[0]; // Poravnato sa levom ivicom

        // Pronalaženje trenutnih granica svih objekata u sloju
        var minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
        var hasObjects = false;

        for (var i = 0; i < layer.pageItems.length; i++) {
            var item = layer.pageItems[i];
            var itemBounds = item.geometricBounds; // [yTop, xLeft, yBottom, xRight]
            
            minX = Math.min(minX, itemBounds[1]);
            minY = Math.min(minY, itemBounds[0]);
            maxX = Math.max(maxX, itemBounds[3]);
            maxY = Math.max(maxY, itemBounds[2]);
            hasObjects = true;
        }

        if (!hasObjects) {
            alert("Sloj 'ZA MONTAZU' nema objekata za pozicioniranje.");
            return;
        }

        // Izračunavanje pomeraanja
        var deltaX = targetX - minX;
        var deltaY = targetY - maxY;

        // Pomeranje svih objekata u sloju
        for (var j = 0; j < layer.pageItems.length; j++) {
            layer.pageItems[j].translate(deltaX, deltaY);
        }

        // Čišćenje selekcije
        doc.selection = null;
    }

    // Glavno izvršenje
    try {
        var montageLayer = getMontageLayer();
        if (montageLayer) {
            // Prvo oboji pravougaonike
            colorRectangles(montageLayer);
            // Zatim pozicioniraj ceo sloj
            positionLayerBelowArtboard(montageLayer);
        }
    } catch (e) {
        alert("Greška pri obradi sloja: " + e.message);
    }

})();
