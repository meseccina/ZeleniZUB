//@target illustrator

// 07 MONTAZA - AUTO.jsx
// Glavna skripta za automatsku montažu
// Poziva sve montažne skripte u pravom redosledu

(function() {
    try {
        // TEST ALERT - PROVERA GLAVNE SKRIPTE
        alert("TEST - Glavna skripta se izvršava!\n\nPutanja: " + File($.fileName).path + "\nFajl: " + File($.fileName).name);
        
        if (app.documents.length === 0) {
            alert("Nema otvorenog dokumenta.");
            return;
        }

        var doc = app.activeDocument;
        
        // Lista svih montažnih skripti u pravom redosledu
        var scriptFiles = [
            "01_za_montazu_v3.6.jsx",
            "02_pun_naziv_za_montazu_optimized.jsx",
            "03_dupliciranje_teksta_za_montazu_optimized.jsx",
            "05_08_optimized.jsx",
            "06_pozicioniranje_grupe_optimized.jsx",
            "07_08_spot_colors_optimized.jsx",
            "09_grupisanje_optimized.jsx"
        ];
        
        // Putanja do skripti
        var scriptPath = File($.fileName).path;
        
        // Izvršavanje svih skripti
        for (var i = 0; i < scriptFiles.length; i++) {
            var scriptFile = new File(scriptPath + "/" + scriptFiles[i]);
            
            if (scriptFile.exists) {
                try {
                    $.writeln("Izvršavam: " + scriptFiles[i]);
                    alert("USPEŠNO izvršavam: " + scriptFiles[i]);
                    
                    // Proveri putanju fajla
                    alert("Putanja fajla: " + scriptFile.fsName);
                    
                    // Proveri sadržaj fajla
                    if (scriptFile.open("r")) {
                        var content = scriptFile.read();
                        scriptFile.close();
                        alert("Fajl postoji i ima " + content.length + " karaktera");
                    } else {
                        alert("Ne mogu da otvorim fajl: " + scriptFile.fsName);
                    }
                    
                    $.evalFile(scriptFile);
                    alert("ZAVRŠENO izvršavanje: " + scriptFiles[i]);
                } catch (e) {
                    alert("Greška pri izvršavanju skripte " + scriptFiles[i] + ": " + e.message);
                }
            } else {
                alert("Skripta " + scriptFiles[i] + " nije pronađena!");
            }
        }
        
        alert("Montaža završena!");
        
    } catch (e) {
        alert("Greška u glavnoj skripti za montažu: " + e.message);
    }
})();
