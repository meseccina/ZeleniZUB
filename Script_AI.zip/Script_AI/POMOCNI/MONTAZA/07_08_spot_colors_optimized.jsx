//@target illustrator

// Optimizovana skripta koja kombinuje 07_izdvajanje_spot_boja_u_tekst.jsx i 08_dodavanje_spot_boja_u_tekst_v.1.1.jsx
// Sa keširanjem i optimizovanim procesiranjem spot boja

(function() {
    var doc = app.activeDocument;
    
    // Keširanje referenci
    var montageLayer = null;
    var spotColorsSublayer = null;
    
    // Funkcija za keširanje sloja "ZA MONTAZU"
    function getMontageLayer() {
        if (!montageLayer) {
            try {
                montageLayer = doc.layers.getByName("ZA MONTAZU");
            } catch (e) {
                // Kreiraj sloj ako ne postoji
                montageLayer = doc.layers.add();
                montageLayer.name = "ZA MONTAZU";
            }
        }
        return montageLayer;
    }
    
    // Funkcija za keširanje pod-sloja "SPOT BOJE"
    function getSpotColorsSublayer() {
        if (!spotColorsSublayer) {
            var layer = getMontageLayer();
            try {
                spotColorsSublayer = layer.layers.getByName("SPOT BOJE");
            } catch (e) {
                // Kreiraj pod-sloj ako ne postoji
                spotColorsSublayer = layer.layers.add();
                spotColorsSublayer.name = "SPOT BOJE";
            }
        }
        return spotColorsSublayer;
    }
    
    // Optimizovana funkcija za prikupljanje boja
    function collectSpotColors() {
        var swatchesPanel = doc.swatches;
        var colorList = [];
        
        // Optimizovana lista za preskakanje (set umesto array za brže pretraživanje)
        var skipNames = {
            "[Passermarken]": true,
            "[Registration]": true,
            "Rasklop": true,
            "[None]": true,
            "TRANSPARENT": true,
            "[Repérage]": true,
            "[Registrační] 1": true
        };
        
        for (var i = 0; i < swatchesPanel.length; i++) {
            var swatch = swatchesPanel[i];
            var swatchName = swatch.name;
            
            // PROVERA DA LI JE SPOT BOJA
            var isSpotColor = false;
            var colorType = "Nepoznato";
            try {
                if (swatch.color.typename === "SpotColor") {
                    isSpotColor = true;
                    colorType = "SpotColor";
                } else if (swatch.color.spot) {
                    isSpotColor = true;
                    colorType = "Spot";
                } else if (swatch.color.typename === "ProcessColor") {
                    colorType = "ProcessColor";
                } else if (swatch.color.typename === "GradientColor") {
                    colorType = "GradientColor";
                } else if (swatch.color.typename === "PatternColor") {
                    colorType = "PatternColor";
                }
            } catch (e) {
                // Ako ne može da proveri tip boje, preskači
                colorType = "Greška: " + e.message;
            }
            
            // DEBUG - prikaži sve boje i tipove
            var debugMessage = "BOJA: " + swatchName + " | TIP: " + colorType + " | SPOT: " + isSpotColor;
            $.writeln(debugMessage);
            
            // Dodaj u debug listu za kasniji prikaz
            if (typeof window.debugList === 'undefined') {
                window.debugList = [];
            }
            window.debugList.push(debugMessage);
            
            // Brza provera da li je naziv u listi za preskakanje
            if (!skipNames[swatchName] && isSpotColor) {
                // Optimizovano preimenovanje Pantone boja
                if (swatchName.indexOf("PANTONE ") === 0) {
                    swatchName = "P" + swatchName.substring(8);
                }
                
                // Specijalna obrada za "Bela" boju - računaj i nACRTAJ
                if (swatchName === "Bela") {
                    // Dodaj belu boju u listu za nACRTANJE
                    colorList.push("NACRTAJ " + swatchName);
                } else {
                    // Normalno dodavanje ostalih boja
                    colorList.push(swatchName);
                }
            }
        }
        
        return colorList;
    }
    
    // Funkcija za kreiranje teksta sa bojama
    function createSpotColorsText(colorList) {
        var sublayer = getSpotColorsSublayer();
        
        // Spajanje naziva boja u jedan string
        var combinedColors = colorList.join(", ");
        
        // Optimizacija: zamena " C," sa ", " i uklanjanje završnog " C"
        combinedColors = combinedColors.replace(/ C,/g, ", ");
        if (combinedColors.slice(-2) === " C") {
            combinedColors = combinedColors.slice(0, -2);
        }
        
        // Kreiranje novog tekstualnog objekta
        var newText = doc.textFrames.add();
        newText.contents = combinedColors;
        newText.move(sublayer, ElementPlacement.PLACEATEND);
        
        // Optimizovano pozicioniranje
        var activeAB = doc.artboards[doc.artboards.getActiveArtboardIndex()];
        var abBounds = activeAB.artboardRect;
        
        var targetX = abBounds[0];
        var targetY = abBounds[3] + 160;
        
        var gb = newText.geometricBounds;
        var deltaX = targetX - gb[1];
        var deltaY = targetY - gb[2];
        
        newText.translate(deltaX, deltaY);
        
        // Postavljanje fonta i poravnanja
        try {
            newText.textRange.characterAttributes.textFont = app.textFonts.getByName("ArialNarrow-Bold");
        } catch (e) {
            // Font ne postoji, koristi default
        }
        
        newText.textRange.paragraphAttributes.justification = Justification.CENTER;
        
        return combinedColors;
    }
    
    // Optimizovana funkcija za dodavanje spot boja u tekstove
    function addSpotColorsToTexts(spotColors) {
        var layer = getMontageLayer();
        var textObjectNames = ["Tekst 05", "Tekst 06", "Tekst 07", "Tekst 08"];
        
        for (var i = 0; i < spotColors.length && i < textObjectNames.length; i++) {
            try {
                var textObj = layer.textFrames.getByName(textObjectNames[i]);
                var currentText = textObj.contents;
                
                if (/C$/.test(currentText)) {
                    var updatedText = currentText.replace(/C$/, spotColors[i]);
                    textObj.contents = updatedText;
                }
            } catch (e) {
                // Tekstualni objekat ne postoji, preskačemo
            }
        }
    }
    
    // Funkcija za brisanje spot sloja
    function deleteSpotLayer() {
        if (spotColorsSublayer) {
            try {
                spotColorsSublayer.remove();
            } catch (e) {
                // Greška pri brisanju, ignorišemo
            }
        }
    }
    
    // Glavno izvršenje
    try {
        // TEST ALERT - PROVERA DA LI SE MENJA FAJL
        alert("TEST - Skripta 07_08_spot_colors_optimized.jsx se izvršava!");
        
        // 1) Prikupljanje spot boja (iz skripte 07)
        var colorList = collectSpotColors();
        
        alert("POSLE collectSpotColors: " + colorList.length + " boja");
        
        if (colorList.length > 0) {
            // 2) Kreiranje teksta sa bojama
            var spotColors = createSpotColorsText(colorList);
            
            // 3) Dodavanje spot boja u tekstove (iz skripte 08)
            var colorArray = spotColors.split(", ");
            addSpotColorsToTexts(colorArray);
            
            // 4) Brisanje spot sloja
            deleteSpotLayer();
            
            // Detaljni alert - prikaži broj i spisak boja
            var belaCount = 0;
            var nacrtajCount = 0;
            var otherColors = [];
            
            for (var j = 0; j < colorList.length; j++) {
                var colorName = colorList[j];
                if (colorName.indexOf("NACRTAJ ") === 0) {
                    nacrtajCount++;
                } else if (colorName === "_Bela_") {
                    belaCount++;
                } else {
                    otherColors.push(colorName);
                }
            }
            
            var alertMessage = "Pronađeno boja: " + colorList.length + "\n\n";
            alertMessage += "Belih boja (_Bela_): " + belaCount + "\n";
            alertMessage += "Za nacrtanje: " + nacrtajCount + "\n";
            alertMessage += "Ostale boje: " + otherColors.join(", ") + "\n\n";
            
            // DEBUG - prikaži sve boje i tipove
            if (typeof window.debugList !== 'undefined' && window.debugList.length > 0) {
                alertMessage += "DEBUG INFO:\n" + window.debugList.slice(-10).join("\n");
            }
            
            alert(alertMessage);
        }
        
    } catch (e) {
        alert("Greška u optimizovanoj skripti za spot boje: " + e.message);
    }
    
})();
