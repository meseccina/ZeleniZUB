//@target illustrator

// Optimizovana verzija 09_grupisanje.jsx sa keširanjem

function groupShapesWithText() {
    try {
        var doc = app.activeDocument;
        
        // Keširanje reference na sloj
        var layer = null;
        try {
            layer = doc.layers.getByName("ZA MONTAZU");
        } catch (e) {
            alert("Sloj 'ZA MONTAZU' nije pronađen!");
            return;
        }

        var rectNames = ["01", "02", "03", "04", "05", "06", "07", "08"];
        var textNames = ["Tekst 01", "Tekst 02", "Tekst 03", "Tekst 04", "Tekst 05", "Tekst 06", "Tekst 07", "Tekst 08"];

        // Keširanje svih pathItems i textFrames za brži pristup
        var pathItemsMap = {};
        var textFramesMap = {};
        
        // Optimizovano mapiranje pravougaonika
        for (var i = 0; i < layer.pathItems.length; i++) {
            var pathItem = layer.pathItems[i];
            // Manualna provera umesto .indexOf()
            var isRectName = false;
            for (var n = 0; n < rectNames.length; n++) {
                if (pathItem.name === rectNames[n]) {
                    isRectName = true;
                    break;
                }
            }
            if (isRectName) {
                pathItemsMap[pathItem.name] = pathItem;
            }
        }
        
        // Optimizovano mapiranje tekstova
        for (var j = 0; j < layer.textFrames.length; j++) {
            var textFrame = layer.textFrames[j];
            // Manualna provera umesto .indexOf()
            var isTextName = false;
            for (var p = 0; p < textNames.length; p++) {
                if (textFrame.name === textNames[p]) {
                    isTextName = true;
                    break;
                }
            }
            if (isTextName) {
                textFramesMap[textFrame.name] = textFrame;
            }
        }

        // Optimizovano grupisanje
        for (var k = 0; k < rectNames.length; k++) {
            var rectObj = pathItemsMap[rectNames[k]];
            var textObj = textFramesMap[textNames[k]];

            if (rectObj && textObj) {
                var group = layer.groupItems.add();
                rectObj.move(group, ElementPlacement.INSIDE);
                textObj.move(group, ElementPlacement.INSIDE);
            }
        }

    } catch (e) {
        alert("Došlo je do greške: " + e.message);
    }
}

groupShapesWithText();
