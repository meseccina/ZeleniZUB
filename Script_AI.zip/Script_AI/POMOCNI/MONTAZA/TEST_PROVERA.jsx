//@target illustrator

// TEST PROVERA - Jednostavna skripta za proveru
alert("TEST PROVERA - Ova skripta radi!\n\nPutanja: " + File($.fileName).path + "\nFajl: " + File($.fileName).name);
