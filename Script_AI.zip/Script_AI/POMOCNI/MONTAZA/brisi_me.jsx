// Brisi Me - Skripta za brisanje objekata sa nazivom "brisi me"
// -------------------------------------------------------
#target illustrator

function deleteBrisiMeObjects() {
    try {
        if (app.documents.length === 0) {
            alert("Nema otvorenog dokumenta!");
            return;
        }
        
        var doc = app.activeDocument;
        
        // Proveri da li postoji sloj ZA MONTAZU
        var montageLayer = null;
        try {
            montageLayer = doc.layers["ZA MONTAZU"];
        } catch (e) {
            alert("Sloj 'ZA MONTAZU' ne postoji!");
            return;
        }
        
        if (!montageLayer) {
            return;
        }
        
        var deletedCount = 0;
        
        // Proveri da li pageItems postoji
        if (!montageLayer.pageItems) {
            return;
        }
        
        // Pretraži sve pageItems
        for (var i = montageLayer.pageItems.length - 1; i >= 0; i--) {
            var item = montageLayer.pageItems[i];
            
            // Proveri naziv bez obzira na tip
            if (item.name === "brisi me") {
                if (item.typename === "TextFrame") {
                    var textContent = item.contents;
                    if (textContent && textContent.length > 20) {
                        textContent = textContent.substring(0, 20) + "...";
                    }
                }
                
                item.remove();
                deletedCount++;
            }
        }
        
        if (deletedCount > 0) {
            return;
        } else {
            // Nema alert ako nema objekata - samo ćuti
        }
        
    } catch (e) {
        // Nema alert za greške - samo ćuti
    }
}

// Pokreni funkciju
deleteBrisiMeObjects();
