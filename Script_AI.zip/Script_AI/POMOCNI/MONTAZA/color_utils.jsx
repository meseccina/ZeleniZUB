#target illustrator

// Color Utils - Pomoćne funkcije za čitanje boja iz MOVE TABELI

// Funkcija za čitanje procesnih boja
function readProcessColors(doc) {
    try {
        var moveTableLayer = doc.layers["MOVE TABELA 26"];
        if (!moveTableLayer) return null;
        
        var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
        if (!bojeGroup) return null;
        
        var processGroup = bojeGroup.groupItems["PROCESNE BOJE"];
        if (!processGroup) return null;
        
        var existingColors = {
            cyan: false,
            magenta: false,
            yellow: false,
            black: false
        };
        
        // Proveri path objekte
        for (var i = 0; i < processGroup.pageItems.length; i++) {
            var item = processGroup.pageItems[i];
            if (item.name === "Cyan") existingColors.cyan = true;
            if (item.name === "Magenta") existingColors.magenta = true;
            if (item.name === "Yellow") existingColors.yellow = true;
            if (item.name === "Black") existingColors.black = true;
        }
        
        return existingColors;
        
    } catch (e) {
        return null;
    }
}

// Funkcija za čitanje spot boja
function readSpotColors(doc) {
    try {
        var moveTableLayer = doc.layers["MOVE TABELA 26"];
        if (!moveTableLayer) return [];
        
        var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
        if (!bojeGroup) return [];
        
        var spotGroup = bojeGroup.groupItems["SPOT BOJE"];
        if (!spotGroup) return [];
        
        var spotColors = [];
        
        // Čitaj sve tekst objekte u SPOT BOJE grupi, bez obzira na ime
        for (var j = 0; j < spotGroup.textFrames.length; j++) {
            var textItem = spotGroup.textFrames[j];
            var colorName = textItem.contents;
            var colorString = String(colorName);
            
            if (colorString && colorString !== "") {
                spotColors.push(colorString);
            }
        }
        
        return spotColors;
        
    } catch (e) {
        return [];
    }
}

// Funkcija za čitanje svih boja iz swatches-a
function readAllSwatchColors(doc) {
    var allSwatchColors = [];
    
    // Crna lista boja koje se ne broje
    var blacklistedColors = [
        "[None]", "[Registration]", "White", "Black",
        "CutContour", "Varnish", "SpotUV", "Metallic",
        "Gold", "Silver", "Bronze", "Copper",
        "TRANSPARENT", "Rasklop"
    ];
    
    try {
        // Prođi kroz sve swatches
        for (var i = 0; i < doc.swatches.length; i++) {
            var swatch = doc.swatches[i];
            var colorName = swatch.name;
            
            // Proveri da li je boja na crnoj listi
            var isBlacklisted = false;
            for (var j = 0; j < blacklistedColors.length; j++) {
                if (colorName === blacklistedColors[j]) {
                    isBlacklisted = true;
                    break;
                }
            }
            
            // Dodaj boju ako nije na crnoj listi i nije prazna
            if (!isBlacklisted && colorName && colorName !== "") {
                allSwatchColors.push(colorName);
            }
        }
        
    } catch (e) {
        // Greška pri čitanju swatches-a
    }
    
    return allSwatchColors;
}

// Funkcija za kombinovanje svih boja u pravom redosledu
function getAllColors(doc) {
    var allColors = [];
    
    // Procesne boje
    var processColors = readProcessColors(doc);
    if (processColors) {
        if (processColors.cyan) allColors.push("C");
        if (processColors.magenta) allColors.push("M");
        if (processColors.yellow) allColors.push("Y");
        if (processColors.black) allColors.push("K");
    }
    
    // Spot boje iz swatches-a
    var swatchColors = readAllSwatchColors(doc);
    for (var i = 0; i < swatchColors.length; i++) {
        allColors.push(swatchColors[i]);
    }
    
    return allColors;
}
