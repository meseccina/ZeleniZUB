// Grupisanje Teksta i Pravougaonika - Skripta za grupisanje "Tekst 01 + 01", "Tekst 02 + 02", itd.
// Čuva postojeće boje i ne uništava ih
// -------------------------------------------------------
#target illustrator

function groupTextAndRectangles() {
    try {
        if (app.documents.length === 0) {
            return; // Nema otvorenog dokumenta
        }
        
        var doc = app.activeDocument;
        
        // Proveri da li postoji sloj ZA MONTAZU
        var montageLayer = null;
        try {
            montageLayer = doc.layers["ZA MONTAZU"];
        } catch (e) {
            return; // Sloj ne postoji
        }
        
        if (!montageLayer) {
            return; // Sloj ne postoji
        }
        
        var groupedCount = 0;
        
        // Pretraži sve pageItems
        var textItems = [];
        var rectangleItems = [];
        
        for (var i = 0; i < montageLayer.pageItems.length; i++) {
            var item = montageLayer.pageItems[i];
            
            // Prikupi tekstove sa nazivom "Tekst XX"
            if (item.typename === "TextFrame" && item.name.indexOf("Tekst ") === 0) {
                textItems.push(item);
            }
            
            // Prikupi pravougaonike sa nazivom broja (01, 02, itd.)
            if (item.typename === "PathItem" && /^\d{2}$/.test(item.name)) {
                rectangleItems.push(item);
            }
        }
        
        // Grupišemo tekstove sa pravougaonicima
        for (var j = 0; j < textItems.length; j++) {
            var textItem = textItems[j];
            var textName = textItem.name; // "Tekst 01", "Tekst 02", itd.
            var rectNumber = textName.replace("Tekst ", ""); // "01", "02", itd.
            
            // Nađi odgovarajući pravougaonik
            var matchingRect = null;
            for (var k = 0; k < rectangleItems.length; k++) {
                if (rectangleItems[k].name === rectNumber) {
                    matchingRect = rectangleItems[k];
                    break;
                }
            }
            
            if (matchingRect) {
                // Grupiši tekst i pravougaonik
                var group = montageLayer.groupItems.add();
                
                // Prvo dodaj pravougaonik, pa tekst - tako da tekst bude iznad
                matchingRect.moveToBeginning(group);
                textItem.moveToBeginning(group);
                
                group.name = "Tekst " + rectNumber + " + " + rectNumber;
                
                groupedCount++;
            }
        }
        
    } catch (e) {
        // Nema alert za greške - samo ćuti
    }
}

// Pokreni funkciju
groupTextAndRectangles();
