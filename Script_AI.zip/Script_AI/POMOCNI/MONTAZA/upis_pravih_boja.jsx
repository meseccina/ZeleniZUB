// Upisivanje Pravih Boja - Skripta koja čita boje iz MOVE TABELA 26 i upisuje ih u tekst
// Koristi iste funkcije kao 01_za_montazu_v3.6.jsx za čitanje boja
// -------------------------------------------------------
#target illustrator

// Konstanta za konverziju iz milimetara u tačke
var MM_TO_POINTS = 2.834645669;

// Funkcija za čitanje procesnih boja
function readProcessColors(doc) {
    try {
        var moveTableLayer = doc.layers["MOVE TABELA 26"];
        if (!moveTableLayer) return null;
        
        var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
        if (!bojeGroup) return null;
        
        var processGroup = bojeGroup.groupItems["PROCESNE BOJE"];
        if (!processGroup) return null;
        
        var existingColors = {
            cyan: false,
            magenta: false,
            yellow: false,
            black: false
        };
        
        for (var i = 0; i < processGroup.pageItems.length; i++) {
            var item = processGroup.pageItems[i];
            if (item.name === "Cyan") existingColors.cyan = true;
            if (item.name === "Magenta") existingColors.magenta = true;
            if (item.name === "Yellow") existingColors.yellow = true;
            if (item.name === "Black") existingColors.black = true;
        }
        
        return existingColors;
    } catch (e) {
        return null;
    }
}

// Funkcija za čitanje spot boja
function readSpotColors(doc) {
    try {
        var moveTableLayer = doc.layers["MOVE TABELA 26"];
        if (!moveTableLayer) return [];
        
        var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
        if (!bojeGroup) return [];
        
        var spotGroup = bojeGroup.groupItems["SPOT BOJE"];
        if (!spotGroup) return [];
        
        var spotColors = [];
        
        for (var j = 1; j <= 3; j++) {
            try {
                var textItem = spotGroup.textFrames.getByName("text.b_0" + j);
                var colorName = textItem.contents;
                var colorString = String(colorName);
                
                if (colorString && colorString !== "") {
                    spotColors.push(colorString);
                }
            } catch (e) {
                // Text frame ne postoji, preskačemo
            }
        }
        
        return spotColors;
    } catch (e) {
        return [];
    }
}

// Funkcija za kombinovanje svih boja u pravom redosledu
function getAllColors(doc) {
    var allColors = [];
    
    // Procesne boje
    var processColors = readProcessColors(doc);
    if (processColors) {
        if (processColors.cyan) allColors.push("C");
        if (processColors.magenta) allColors.push("M");
        if (processColors.yellow) allColors.push("Y");
        if (processColors.black) allColors.push("K");
    }
    
    // Spot boje
    var spotColors = readSpotColors(doc);
    for (var i = 0; i < spotColors.length; i++) {
        allColors.push(spotColors[i]);
    }
    
    // Bela boja (uvek fiksna)
    allColors.push("BELA");
    
    return allColors;
}

// Funkcija za upisivanje pravih boja u tekstove
function writeRealColorsToTexts() {
    try {
        if (app.documents.length === 0) {
            return; // Nema otvorenog dokumenta
        }
        
        var doc = app.activeDocument;
        
        // Proveri da li postoji sloj ZA MONTAZU
        var montageLayer = null;
        try {
            montageLayer = doc.layers["ZA MONTAZU"];
        } catch (e) {
            return; // Sloj ne postoji
        }
        
        if (!montageLayer) {
            return; // Sloj ne postoji
        }
        
        // Dobavi sve boje iz dokumenta
        var allColors = getAllColors(doc);
        
        // Upisi boje u tekstove
        for (var i = 0; i < allColors.length && i < 8; i++) {
            var textName = "Tekst " + (i + 1).toString().padStart(2, '0');
            
            try {
                var textObj = montageLayer.textFrames.getByName(textName);
                var currentText = textObj.contents;
                
                // Zameni poslednje "C" sa pravom bojom
                if (currentText && /C$/.test(currentText)) {
                    var updatedText = currentText.replace(/C$/, allColors[i]);
                    textObj.contents = updatedText;
                }
            } catch (e) {
                // Text ne postoji, preskačemo
            }
        }
        
    } catch (e) {
        // Nema alert za greške - samo ćuti
    }
}

// Pokreni funkciju
writeRealColorsToTexts();
