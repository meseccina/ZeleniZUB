#target illustrator

(function () {

    if (app.documents.length === 0) {
        alert("Nema otvorenog dokumenta.");
        return;
    }

    var doc = app.activeDocument;
    var report = "🔎 0% Tint Spot Objects Report\n\n";
    var count = 0;

    function scanItem(item, layerName, parentIndex) {
        try {
            if (item.typename === "GroupItem") {
                for (var i = 0; i < item.pageItems.length; i++) {
                    scanItem(item.pageItems[i], layerName, parentIndex + "." + i);
                }
            } else {
                if (item.filled && item.fillColor.typename === "SpotColor" && item.fillColor.tint === 0) {
                    report += "✅ Fill 0% | Layer: " + layerName + " | Spot: " + item.fillColor.spot.name + " | Index: " + parentIndex + "\n";
                    count++;
                }
                if (item.stroked && item.strokeColor.typename === "SpotColor" && item.strokeColor.tint === 0) {
                    report += "✅ Stroke 0% | Layer: " + layerName + " | Spot: " + item.strokeColor.spot.name + " | Index: " + parentIndex + "\n";
                    count++;
                }
            }
        } catch (e) {}
    }

    for (var l = 0; l < doc.layers.length; l++) {
        var layer = doc.layers[l];
        for (var i = 0; i < layer.pageItems.length; i++) {
            scanItem(layer.pageItems[i], layer.name, i.toString());
        }
    }

    if (count === 0) {
        report += "Nema objekata sa 0% tint.\n";
    } else {
        report += "\nUkupno objekata sa 0% tint: " + count;
    }

    alert(report);

})();
