// Provera da li je selektovan tekstualni objekat
if (app.selection.length === 1 && app.selection[0].typename === "TextFrame") {
    var textFrame = app.selection[0];
    
    // Brisanje sav tekst u tekstualnom objektu
    textFrame.contents = "";

    // Uzimanje imena dokumenta
    var documentName = app.activeDocument.name;
    
    // Pronalaženje prvog indeksa " - "
    var indexOfDash = documentName.indexOf(" - ");
    
    // Uzimanje teksta do prvog " - "
    var newText = documentName.substring(0, indexOfDash);
    
    // Upisivanje novog teksta u tekstualni objekat
    textFrame.contents = newText;
} else {
    alert("Molimo vas selektujte samo jedan tekstualni objekat.");
}
