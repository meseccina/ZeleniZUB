// Provera da li postoji selektovani tekst
if (app.selection.length > 0 && app.selection[0].typename == "TextFrame") {
    var selectedText = app.selection[0];
    
    // Izbrisati stari tekst
    selectedText.contents = "";
    
    // Dobijanje putanje do dokumenta
    var currentDoc = app.activeDocument;
    var docPath = currentDoc.path;
    var docName = currentDoc.name;
    var fullPath = docPath + "/" + docName;
    
    // Zamjena dijela teksta
    var updatedPath = fullPath.replace("//Nas6bf537/flexo/MOVE/", "");
    
    // Brisanje dela teksta nakon prvog "/"
    var indexOfSlash = updatedPath.indexOf("/");
    if (indexOfSlash !== -1) {
        updatedPath = updatedPath.substring(0, indexOfSlash);
    }
    
    // Upisivanje putanje u selektovani tekst
    selectedText.contents = updatedPath;
} else {
    alert("Nema selektovanog teksta ili nije tekstualni okvir.");
}
// Provera da li postoji selektovani tekst
if (app.selection.length > 0 && app.selection[0].typename == "TextFrame") {
    var selectedText = app.selection[0];
    
    // Izbrisati stari tekst
    selectedText.contents = "";
    
    // Dobijanje putanje do dokumenta
    var currentDoc = app.activeDocument;
    var docPath = currentDoc.path;
    var docName = currentDoc.name;
    var fullPath = docPath + "/" + docName;
    
    // Zamjena dijela teksta
    var updatedPath = fullPath.replace("//Nas6bf537/flexo/MOVE/", "");
    
    // Brisanje dela teksta nakon prvog "/"
    var indexOfSlash = updatedPath.indexOf("/");
    if (indexOfSlash !== -1) {
        updatedPath = updatedPath.substring(0, indexOfSlash);
    }
    
    // Zamjena "%20" sa " "
    updatedPath = updatedPath.replace(/%20/g, " ");
    
    // Upisivanje putanje u selektovani tekst
    selectedText.contents = updatedPath;
} else {
    alert("Nema selektovanog teksta ili nije tekstualni okvir.");
}
