// Provera da li postoji selektovani tekst
if (app.selection.length > 0 && app.selection[0].typename == "TextFrame") {
    var selectedText = app.selection[0];
    
    // Izbrisati stari tekst
    selectedText.contents = "";
    
    // Dobijanje putanje do dokumenta
    var currentDoc = app.activeDocument;
    var docPath = currentDoc.path;
    var docName = currentDoc.name;
    var fullPath = docPath + "/" + docName;
    
    // Pronalazak osnovnog dela putanje (da li počinje sa "//Nas6bf537/flexo/")
    var basePath = "//Nas6bf537/flexo/";

    // Proveravamo da li putanja počinje sa "//Nas6bf537/flexo/"
    if (fullPath.indexOf(basePath) !== -1) {
        // Pronalazimo deo putanje nakon "//Nas6bf537/flexo/"
        var startIndex = fullPath.indexOf(basePath) + basePath.length;
        var updatedPath = fullPath.substring(startIndex);
        
        // Brisanje dela teksta nakon prvog "/"
        var indexOfSlash = updatedPath.indexOf("/");
        if (indexOfSlash !== -1) {
            updatedPath = updatedPath.substring(0, indexOfSlash);
        }
        
        // Zamena "%20" sa razmakom
        updatedPath = updatedPath.replace(/%20/g, " ");
        
        // Upisivanje putanje u selektovani tekst
        selectedText.contents = updatedPath;
    } else {
        alert("Putanja nije prepoznata.");
    }
} else {
    alert("Nema selektovanog teksta ili nije tekstualni okvir.");
}
