// Provera da li je selektovan tekstualni objekat
function isTextSelected() {
  var selection = app.activeDocument.selection;
  if (selection.length > 0 && selection[0].typename == "TextFrame") {
    return true;
  }
  return false;
}

// Funkcija za upisivanje teksta iz naziva dokumenta u selektovani tekstualni objekat
function insertTextFromDocumentName() {
  var documentName = app.activeDocument.name;
  var parts = documentName.split(" - ");
  if (parts.length >= 2) {
    var textToInsert = parts[1];
    if (isTextSelected()) {
      var textFrame = app.activeDocument.selection[0];
      textFrame.contents = textToInsert;
          } else {
      alert("Nije selektovan tekstualni objekat.");
    }
  } else {
    alert("Naziv dokumenta ne sadrži potreban format.");
  }
}

// Pozivanje funkcije za upisivanje teksta iz naziva dokumenta
insertTextFromDocumentName();
