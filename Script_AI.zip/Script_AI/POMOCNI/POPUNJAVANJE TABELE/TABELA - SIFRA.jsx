function izdvojiRecIzImenaFajla(imeFajla) {
    // Novi regularni izraz koji prepoznaje sve šifre koje sadrže "_v" ili "_V"
    var regex = /[A-Za-z0-9_]+_v\d+/i;
    var rezultat = imeFajla.match(regex);

    if (rezultat !== null) {
        return rezultat[0]; // Vraćamo pronađeni deo imena fajla
    } else {
        return "";
    }
}

function main() {
    // Provera da li je selektovan samo jedan tekstualni objekat
    if (app.selection.length === 1 && app.selection[0].typename === "TextFrame") {
        var selektovaniTekst = app.selection[0]; // Dobijamo selektovani tekstualni objekat
        var imeDokumenta = app.activeDocument.name; // Dobijamo ime aktivnog dokumenta

        var zeljeniDeoTeksta = izdvojiRecIzImenaFajla(imeDokumenta); // Dobijamo željeni deo teksta iz imena dokumenta

        // Provera da li smo dobili željeni deo teksta
        if (zeljeniDeoTeksta !== "") {
            // Postavljanje željenog dela teksta u selektovani tekstualni objekat
            selektovaniTekst.contents = zeljeniDeoTeksta;
        } else {
            alert("Nije pronađen željeni deo teksta u imenu dokumenta. Proverite da li se ime dokumenta podudara sa očekivanim formatom.");
        }
    } else {
        alert("Molimo vas selektujte samo jedan tekstualni objekat.");
    }
}

main();
