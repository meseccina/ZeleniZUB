#target illustrator

// Funkcija za izdvajanje željenog dela teksta iz imena fajla
function izdvojiRecIzImenaFajla(imeFajla) {
    var regex = /[0-9]+_v[0-9]+/i; // Regularni izraz za pronalaženje dela sa "_v" (neosetljiv na velika i mala slova)
    var rezultat = imeFajla.match(regex); // Pronalazimo odgovarajući deo imena fajla koristeći regularni izraz

    if (rezultat !== null) {
        return rezultat[0]; // Vraćamo pronađeni deo imena fajla
    } else {
        return null; // Ako nije pronađen, vraćamo null
    }
}

// Glavna funkcija koja će se izvršiti kada se pokrene skript
function main() {
    // Provera da li je selektovan samo jedan tekstualni objekat
    if (app.selection.length === 1 && app.selection[0].typename === "TextFrame") {
        var selektovaniTekst = app.selection[0]; // Dobijamo selektovani tekstualni objekat
        var imeDokumenta = app.activeDocument.name; // Dobijamo ime aktivnog dokumenta

        var zeljeniDeoTeksta = izdvojiRecIzImenaFajla(imeDokumenta); // Dobijamo željeni deo teksta iz imena dokumenta

        // Provera da li smo dobili željeni deo teksta
        if (zeljeniDeoTeksta !== null) {
            // Postavljanje željenog dela teksta u selektovani tekstualni objekat
            selektovaniTekst.contents = zeljeniDeoTeksta;
        } else {
            alert("Nije pronađen željeni deo teksta u imenu dokumenta. Proverite da li se ime dokumenta podudara sa očekivanim formatom.");
        }
    } else {
        alert("Molimo vas selektujte samo jedan tekstualni objekat.");
    }
}

// Poziv glavne funkcije
main();
