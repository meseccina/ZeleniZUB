#target illustrator

// Funkcija za prikazivanje prozora sa checkboxovima
function showDialog() {
    var dlg = new Window("dialog", "Odaberi boje koje neće biti korišćene");

    // Checkbox za "Koriste se SVE PROCESNE BOJE" (po defaultu je označen)
    dlg.checkboxAll = dlg.add("checkbox", undefined, "Koriste se SVE PROCESNE BOJE");
    dlg.checkboxAll.value = true;  // Postavljamo da bude označen po defaultu

    // Grupa za "NE KORISTE SE SLEDEĆE BOJE"
    var colorGroup = dlg.add("panel", undefined, "NE KORISTE SE SLEDEĆE BOJE");
    colorGroup.orientation = "column";

    // Checkbox za svaku boju
    colorGroup.checkboxCyan = colorGroup.add("checkbox", undefined, "Cyan");
    colorGroup.checkboxMagenta = colorGroup.add("checkbox", undefined, "Magenta");
    colorGroup.checkboxYellow = colorGroup.add("checkbox", undefined, "Yellow");
    colorGroup.checkboxBlack = colorGroup.add("checkbox", undefined, "Black");

    // Dodavanje dugmadi za potvrdu
    dlg.add("button", undefined, "OK");

    // Funkcija koja omogućava da se spreči kombinacija sa "Koriste se SVE PROCESNE BOJE"
    dlg.checkboxAll.onClick = function() {
        // Ako je "Koriste se SVE PROCESNE BOJE" označen, odznačimo ostale
        if (dlg.checkboxAll.value) {
            colorGroup.checkboxCyan.value = false;
            colorGroup.checkboxMagenta.value = false;
            colorGroup.checkboxYellow.value = false;
            colorGroup.checkboxBlack.value = false;
        }
    };

    // Funkcija koja sprečava da se selektuje "Koriste se SVE PROCESNE BOJE" kada su ostali checkboxovi selektovani
    colorGroup.checkboxCyan.onClick = colorGroup.checkboxMagenta.onClick = colorGroup.checkboxYellow.onClick = colorGroup.checkboxBlack.onClick = function() {
        // Ako je neki od preostalih checkboxova selektovan, odznačimo "Koriste se SVE PROCESNE BOJE"
        if (colorGroup.checkboxCyan.value || colorGroup.checkboxMagenta.value || colorGroup.checkboxYellow.value || colorGroup.checkboxBlack.value) {
            dlg.checkboxAll.value = false;
        }
    };

    // Kada se pritisne OK, proveravamo šta je selektovano
    if (dlg.show() == 1) {
        if (dlg.checkboxAll.value) {
            // Ako je selektovan checkbox "Koriste se SVE PROCESNE BOJE", skripta se završava
            return;
        }

        // Ako nije selektovan checkbox za sve boje, brišemo odgovarajuće objekte
        deleteColor("Cyan", colorGroup.checkboxCyan.value);
        deleteColor("Magenta", colorGroup.checkboxMagenta.value);
        deleteColor("Yellow", colorGroup.checkboxYellow.value);
        deleteColor("Black", colorGroup.checkboxBlack.value);
    }
}

// Funkcija za brisanje objekta na osnovu imena
function deleteColor(colorName, shouldDelete) {
    if (shouldDelete) {
        var doc = app.activeDocument;
        var layer = doc.layers["MOVE TABELA 26"];
        var group = layer.groupItems["BOJE U TABELI"];
        var processGroup = group.groupItems["PROCESNE BOJE"];

        // Pretraga objekta unutar grupe "PROCESNE BOJE"
        for (var i = 0; i < processGroup.pageItems.length; i++) {
            var item = processGroup.pageItems[i];
            if (item.name == colorName) {
                item.remove(); // Brisanje objekta
                break;
            }
        }
    }
}

// Poziv funkcije
showDialog();
