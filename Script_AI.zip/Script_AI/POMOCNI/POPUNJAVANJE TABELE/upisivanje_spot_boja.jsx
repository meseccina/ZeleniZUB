#target illustrator

// Funkcija za preimenovanje Pantone boje u željeni format
function formatPantoneName(spotColorName) {
    // Prebacivanje celokupnog imena na velika slova, kako bismo lakše upravljali
    var formattedName = spotColorName.toUpperCase();
    
    // Skraćujemo "PANTONE" u "P" (ako postoji) i ostavljamo ostatak nepromenjen
    formattedName = formattedName.replace(/^PANTONE /, 'P');
    
    // Ako postoji razmak i "C" na kraju, zamenjujemo "C" u "c"
    formattedName = formattedName.replace(/ C$/, 'c');
    
    return formattedName;
}

// Glavna funkcija za dodeljivanje boja i tekstova
function assignSpotColors() {
    var doc = app.activeDocument;

    // Prvo, proverimo postoji li sloj "MOVE TABELA 26"
    var moveLayer = doc.layers.getByName("MOVE TABELA 26");
    
    // Pronađi grupu "BOJE U TABELI" u tom sloju
    var bojeGrupa = moveLayer.groupItems.getByName("BOJE U TABELI");
    
    // Pronađi podgrupu "SPOT BOJE"
    var spotBojeGrupa = bojeGrupa.groupItems.getByName("SPOT BOJE");
    
    // Uzmimo sve spot boje iz palete
    var swatches = doc.swatches;
    var spotColors = [];

    // Lista boja koje želimo da izuzmemo
    var excludedColors = [
        "[Registration]", // Primer: boje koje ne želimo
        "Rasklop",
        "_Bela_",
        "MAT LAK",
        "[Passermarken]",
        "[Registrační] 1",
        "TRANSPARENT"
    ];

    // Iteriramo kroz sve swatcheve i prikupljamo samo spot boje koje nisu na listi isključenih
    for (var i = 0; i < swatches.length; i++) {
        var swatch = swatches[i];
        var swatchName = swatch.name.toUpperCase(); // Uzimamo ime boje u velikim slovima za lakšu pretragu

        var isExcluded = false;
        for (var j = 0; j < excludedColors.length; j++) {
            if (swatchName.indexOf(excludedColors[j].toUpperCase()) !== -1) {
                isExcluded = true; // Ako je boja u listi isključenih, preskačemo je
                break;
            }
        }

        // Ako boja nije na listi isključenih, dodajemo je u niz spotColors
        if (swatch.color.typename === "SpotColor" && !isExcluded) {
            spotColors.push(swatch);
        }
    }

    // Ako postoji manje od 3 spot boje, završavamo skriptu
    if (spotColors.length === 0) {
        alert("Nema spot boja u paleti.");
        return;
    }

    // Dodeljujemo boje pravougaonicima i tekstovima
    for (var j = 0; j < Math.min(spotColors.length, 3); j++) {
        var spotColor = spotColors[j];
        var formattedName = formatPantoneName(spotColor.name);

        // Dodeljujemo boju pravougaonicima
        var rectangle = spotBojeGrupa.pathItems.getByName("boja_0" + (j + 1));
        rectangle.fillColor = spotColor.color;

        // Upisujemo naziv boje u odgovarajući tekst
        var textItem = spotBojeGrupa.textFrames.getByName("text.b_0" + (j + 1));
        textItem.contents = formattedName;
    }
}

// Pozivamo glavnu funkciju
assignSpotColors();
