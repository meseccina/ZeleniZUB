#target illustrator



(function () {



    if (app.documents.length === 0) {

        alert("Nema otvorenog dokumenta.");

        return;

    }



    var doc = app.activeDocument;



    // --- lejere koje uvek isključujemo ---

    var offLayers = ["KOTE", "RASKLOP", "ǀ INFO ZA STAMPU", "MOVE TABELA 25"];

    for (var j = 0; j < offLayers.length; j++) {

        try {

            var lyrOff = doc.layers.getByName(offLayers[j]);

            lyrOff.visible = false;

        } catch (e) {

            // lejer ne postoji, ignoriši

        }

    }



    // --- lejer BELA ili _Bela_ koji uvek uključujemo ---

    var belaNames = ["_Bela_", "BELA"];

    for (var k = 0; k < belaNames.length; k++) {

        try {

            var lyrBela = doc.layers.getByName(belaNames[k]);

            lyrBela.visible = true;

        } catch (e) {

            // lejer ne postoji, ignoriši

        }

    }



})();

