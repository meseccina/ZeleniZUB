#target illustrator

try {
    // Ime akcije
    var actionSetName = "PROCENTI";  // Set / grupa akcija
    var actionName    = "ESKO_PDF";      // Tačna akcija u grupi

    app.doScript(actionName, actionSetName);


} catch (e) {
    alert("Greška pri pokretanju akcije:\n" + e);
}
