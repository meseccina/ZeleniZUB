#target illustrator

// ================================
// POMOĆNE FUNKCIJE – LAYERS
// ================================

// Sačuvaj stanje sloja
function saveLayerState(layer) {
    return {
        layer: layer,
        locked: layer.locked,
        visible: layer.visible
    };
}

// Vrati stanje sloja
function restoreLayerState(state) {
    state.layer.locked = state.locked;
    state.layer.visible = state.visible;
}

// Normalizacija imena
function normalizeName(name) {
    return name.replace(/\s+/g, "").toUpperCase();
}

// ================================
// PROVERA OBAVEZNIH SLOJEVA
// ================================
(function checkRequiredLayers() {

    if (app.documents.length === 0) {
        throw new Error("Nema otvorenih dokumenata.");
    }

    var doc = app.activeDocument;

    var requiredLayers = {
        RASKLOP: ["RASKLOP", "_RASKLOP", "RASKLOP_"],
        BELA: ["_Bela_", "Bela", "BELA", "White", "WHITE"]
    };

    var missing = [];

    for (var key in requiredLayers) {
        var found = false;

        for (var i = 0; i < doc.layers.length; i++) {
            var layerName = normalizeName(doc.layers[i].name);

            for (var j = 0; j < requiredLayers[key].length; j++) {
                if (layerName === normalizeName(requiredLayers[key][j])) {
                    found = true;
                    break;
                }
            }

            if (found) break;
        }

        if (!found) missing.push(key);
    }

    if (missing.length > 0) {
        throw new Error(
            "Nedostaju ključni slojevi: " + missing.join(", ")
        );
    }

})();

// ================================
// SYMBOL FUNKCIJE
// ================================

function checkSymbolExistence(symbolName) {
    var symbols = app.activeDocument.symbols;
    for (var i = 0; i < symbols.length; i++) {
        if (symbols[i].name === symbolName) return true;
    }
    return false;
}

function importSymbol(symbolName) {
    var doc = app.activeDocument;
    var symbol = doc.symbols.getByName(symbolName);
    return doc.symbolItems.add(symbol);
}

function breakSymbolLink(symbolItem) {
    symbolItem.breakLink();
}

// ================================
// TEMP LAYER
// ================================

function createTempLayer() {
    var layer = app.activeDocument.layers.add();
    layer.name = "TempLayer";
    return layer;
}

function deleteTempLayer() {
    try {
        app.activeDocument.layers.getByName("TempLayer").remove();
    } catch (e) {}
}

// ================================
// MAIN
// ================================

function main() {

    var doc = app.activeDocument;
    var layerStates = [];

    // Privremeno otključa + prikaže sve slojeve
    for (var i = 0; i < doc.layers.length; i++) {
        layerStates.push(saveLayerState(doc.layers[i]));
        doc.layers[i].locked = false;
        doc.layers[i].visible = true;
    }

    var tempLayer = createTempLayer();
    var symbolName = "VODjICE";

    if (checkSymbolExistence(symbolName)) {
        var importedSymbol = importSymbol(symbolName);
        breakSymbolLink(importedSymbol);
    } else {
        alert("Simbol '" + symbolName + "' ne postoji.");
    }

    // Vrati stanje slojeva
    for (var j = 0; j < layerStates.length; j++) {
        restoreLayerState(layerStates[j]);
    }
}

// ================================
// IZVRŠENJE
// ================================

main();

// ================================
// PREMEŠTAJ POD-SLOJA "VODjICE"
// ================================

var doc = app.activeDocument;

for (var i = 0; i < doc.layers.length; i++) {
    var parentLayer = doc.layers[i];

    for (var j = parentLayer.layers.length - 1; j >= 0; j--) {
        var subLayer = parentLayer.layers[j];
        if (normalizeName(subLayer.name) === "VODJICE") {
            subLayer.move(doc, ElementPlacement.PLACEATBEGINNING);
        }
    }
}

// ================================
// CLEANUP
// ================================

deleteTempLayer();
