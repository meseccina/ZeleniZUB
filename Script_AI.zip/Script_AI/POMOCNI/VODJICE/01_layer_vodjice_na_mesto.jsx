// ================================
// MOVE VODJICE LAYER (ROBUST)
// ================================

#target illustrator

// Pristupamo dokumentu
var doc = app.activeDocument;

// -------------------------------
// HELPERS
// -------------------------------

function normalizeName(name) {
    return name.replace(/\s+/g, "").toUpperCase();
}

function findLayerByNames(doc, names) {
    for (var i = 0; i < doc.layers.length; i++) {
        var lname = normalizeName(doc.layers[i].name);
        for (var j = 0; j < names.length; j++) {
            if (lname === normalizeName(names[j])) {
                return doc.layers[i];
            }
        }
    }
    return null;
}

// -------------------------------
// ALTERNATIVE NAMES
// -------------------------------

var RASKLOP_NAMES = ["RASKLOP", "_RASKLOP", "RASKLOP_"];
var BELA_NAMES    = ["_Bela_", "Bela", "BELA", "White", "WHITE"];
var VODJICE_NAMES = ["VODjICE", "VODJICE", "Vodjice"];

// -------------------------------
// FIND LAYERS
// -------------------------------

var rasklopLayer = findLayerByNames(doc, RASKLOP_NAMES);
var belaLayer    = findLayerByNames(doc, BELA_NAMES);
var vodjiceLayer = findLayerByNames(doc, VODJICE_NAMES);

// -------------------------------
// MAIN LOGIC
// -------------------------------

if (rasklopLayer && belaLayer && vodjiceLayer) {

    // Save states
    var states = [
        { layer: rasklopLayer, visible: rasklopLayer.visible, locked: rasklopLayer.locked },
        { layer: belaLayer,    visible: belaLayer.visible,    locked: belaLayer.locked },
        { layer: vodjiceLayer, visible: vodjiceLayer.visible, locked: vodjiceLayer.locked }
    ];

    // Unlock & show
    rasklopLayer.visible = true;
    belaLayer.visible    = true;
    vodjiceLayer.visible = true;

    rasklopLayer.locked  = false;
    belaLayer.locked     = false;
    vodjiceLayer.locked  = false;

    // Move VODJICE before BELA
    vodjiceLayer.move(belaLayer, ElementPlacement.PLACEBEFORE);

    // Restore states
    for (var i = 0; i < states.length; i++) {
        states[i].layer.visible = states[i].visible;
        states[i].layer.locked  = states[i].locked;
    }

} else {
    alert("Nisu pronađeni svi potrebni slojevi:\nRASKLOP / BELA / VODJICE");
}
