// Pronalaženje sloja "VODjICE" korišćenjem regularnog izraza
var vodjiceLayer = null;
for (var i = 0; i < app.activeDocument.layers.length; i++) {
    if (app.activeDocument.layers[i].name.match(/VODjICE/i)) {
        vodjiceLayer = app.activeDocument.layers[i];
        break;
    }
}

// Provera da li je sloj pronađen
if (vodjiceLayer != null) {

    // Provera pod-slojeva "LEVA" i "DESNA" u sloju "VODjICE"
    var levaSubLayer = null;
    var desnaSubLayer = null;
    for (var j = 0; j < vodjiceLayer.groupItems.length; j++) {
        if (vodjiceLayer.groupItems[j].name.match(/LEVA/i)) {
            levaSubLayer = vodjiceLayer.groupItems[j];
        } else if (vodjiceLayer.groupItems[j].name.match(/DESNA/i)) {
            desnaSubLayer = vodjiceLayer.groupItems[j];
        }
    }

    // Provera da li su pod-slojevi pronađeni
    if (levaSubLayer != null && desnaSubLayer != null) {
        // Pronalaženje nove širine artboarda i njegove pozicije
        var artboard = app.activeDocument.artboards[0];
        var artboardRect = artboard.artboardRect;
        var artboardWidth = artboardRect[2] - artboardRect[0];
        var artboardPosition = artboardRect.slice(0, 2);

        // Postavljanje pod-sloja "LEVA" na gornju levu ivicu artboarda SAMO ako nije već na pravom mestu
        var currentX = levaSubLayer.position[0];
        var targetX = artboardPosition[0];
        
        // Pomeri grupu SAMO ako nije već na pravom X mestu (sa tolerancijom od 0.1mm)
        if (Math.abs(currentX - targetX) > 0.283) { // 0.1mm = 0.283 pt
            levaSubLayer.position = artboardPosition;
        }

        // Postavljanje pod-sloja "DESNA" na gornju desnu ivicu artboarda
        desnaSubLayer.position = [artboardPosition[0] + artboardWidth - desnaSubLayer.width, artboardPosition[1]];

    } else {
        alert("Nisu pronađeni pod-slojevi 'LEVA' i/ili 'DESNA' u sloju 'VODjICE'.");
    }
} else {
    alert("Sloj 'VODjICE' nije pronađen.");
}
