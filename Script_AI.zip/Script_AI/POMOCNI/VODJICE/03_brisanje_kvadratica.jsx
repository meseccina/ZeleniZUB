// Pronalaženje sloja nazvanog "VODjICE"
var targetLayer = null;
for (var i = 0; i < app.activeDocument.layers.length; i++) {
    if (app.activeDocument.layers[i].name == "VODjICE") {
        targetLayer = app.activeDocument.layers[i];
        break;
    }
}

// Ako je sloj pronađen
if (targetLayer) {
    // Pronalaženje i brisanje objekata unutar grupa
    for (var j = targetLayer.groupItems.length - 1; j >= 0; j--) {
        var currentGroup = targetLayer.groupItems[j];
        // Pronalaženje objekta "LEVA BRISI ME" unutar grupe i brisanje
        for (var k = currentGroup.pageItems.length - 1; k >= 0; k--) {
            if (currentGroup.pageItems[k].name == "LEVA BRISI ME") {
                currentGroup.pageItems[k].remove();
            }
        }
        // Pronalaženje objekta "DESNA BRISI ME" unutar grupe i brisanje
        for (var l = currentGroup.pageItems.length - 1; l >= 0; l--) {
            if (currentGroup.pageItems[l].name == "DESNA BRISI ME") {
                currentGroup.pageItems[l].remove();
            }
        }
    }
}
