#target illustrator;

// Funkcija za proveru postojećih boja u MOVE TABELI
function checkColorsInMoveTable() {
    try {
        var doc = app.activeDocument;
        
        // Pronađi MOVE TABELA 26 sloj
        var moveTableLayer = doc.layers["MOVE TABELA 26"];
        if (!moveTableLayer) {
            alert("Sloj 'MOVE TABELA 26' nije pronađen!");
            return null;
        }
        
        // Pronađi BOJE U TABELI grupu
        var bojeGroup = moveTableLayer.groupItems["BOJE U TABELI"];
        if (!bojeGroup) {
            alert("Grupa 'BOJE U TABELI' nije pronađena!");
            return null;
        }
        
        // Pronađi PROCESNE BOJE grupu
        var processGroup = bojeGroup.groupItems["PROCESNE BOJE"];
        if (!processGroup) {
            alert("Grupa 'PROCESNE BOJE' nije pronađena!");
            return null;
        }
        
        // Proveri koje boje postoje
        var existingColors = {
            cyan: false,
            magenta: false,
            yellow: false,
            black: false
        };
        
        for (var i = 0; i < processGroup.pageItems.length; i++) {
            var item = processGroup.pageItems[i];
            if (item.name === "Cyan") existingColors.cyan = true;
            if (item.name === "Magenta") existingColors.magenta = true;
            if (item.name === "Yellow") existingColors.yellow = true;
            if (item.name === "Black") existingColors.black = true;
        }
        
        $.writeln("Pronađene boje u MOVE TABELI:");
        $.writeln("Cyan: " + existingColors.cyan);
        $.writeln("Magenta: " + existingColors.magenta);
        $.writeln("Yellow: " + existingColors.yellow);
        $.writeln("Black: " + existingColors.black);
        
        return existingColors;
        
    } catch (e) {
        alert("Greška pri proveri boja: " + e.message);
        return null;
    }
}

// Funkcija za nalaženje sloja po imenu
function findLayerByName(layerName) {
    var doc = app.activeDocument;
    for (var i = 0; i < doc.layers.length; i++) {
        if (doc.layers[i].name === layerName) {
            return doc.layers[i];
        }
    }
    return null;
}

// Funkcija za nalaženje grupe po imenu unutar određenog sloja
function findGroupByName(layer, groupName) {
    for (var i = 0; i < layer.groupItems.length; i++) {
        if (layer.groupItems[i].name === groupName) {
            return layer.groupItems[i];
        }
    }
    return null;
}

// Funkcija za nalaženje tekstualnog objekta po imenu unutar grupe
function findTextByName(group, textName) {
    for (var i = 0; i < group.textFrames.length; i++) {
        if (group.textFrames[i].name === textName) {
            return group.textFrames[i];
        }
    }
    return null;
}

// Kreiraj informativni prozor (automatska provera iz MOVE TABELI)
function showAutoDialog(existingColors) {
    var dialog = new Window("dialog", "PROCESNE BOJE - Automatski iz MOVE TABELI");
    dialog.orientation = "column";
    dialog.alignChildren = ["center", "top"];
    dialog.size = [300, 180]; // Smanjena visina dijaloga
    
    // Dodaj naslov
    var title = dialog.add("statictext", undefined, "Automatski provereno iz MOVE TABELI:");
    title.justify = "center";
    
    // Dodaj informacije o bojama
    var infoGroup = dialog.add("group");
    infoGroup.orientation = "column";
    infoGroup.alignChildren = ["left", "top"];
    
    // Dodaj koje boje nema
    var missingColors = [];
    if (!existingColors.cyan) missingColors.push("Cyan");
    if (!existingColors.magenta) missingColors.push("Magenta");
    if (!existingColors.yellow) missingColors.push("Yellow");
    if (!existingColors.black) missingColors.push("Black");
    
    if (missingColors.length > 0) {
        infoGroup.add("statictext", undefined, "NEĆE BITI NA VODJICAMA:");
        for (var i = 0; i < missingColors.length; i++) {
            var missingText = infoGroup.add("statictext", undefined, "  • " + missingColors[i]);
            missingText.characters = 20;
        }
    }
    
    // Dodaj separator
    dialog.add("panel", undefined, undefined);
    
    // Dodaj dugmad
    var buttonGroup = dialog.add("group");
    buttonGroup.orientation = "row";
    buttonGroup.alignment = ["center", "top"];
    
    var okButton = buttonGroup.add("button", undefined, "NASTAVI");
    var cancelButton = buttonGroup.add("button", undefined, "Otkaži");
    
    // Postavi akcije
    okButton.onClick = function() {
        dialog.close(1);
    };
    
    cancelButton.onClick = function() {
        dialog.close(0);
    };
    
    // Prikaži dijalog i vrati rezultat
    if (dialog.show() == 1) {
        // Vrati obrnutu logiku - koje boje treba ukloniti
        return {
            cyan: !existingColors.cyan,
            magenta: !existingColors.magenta,
            yellow: !existingColors.yellow,
            black: !existingColors.black
        };
    } else {
        return null; // Korisnik je otkazao
    }
}

// Funkcija za upravljanje vidljivošću grupa klinova
function manageKlinoviVisibility(doc, useMaliKlinovi) {
    try {
        // Pronađi sloj "VODjICE"
        var vodjiceLayer = findLayerByName("VODjICE");
        if (!vodjiceLayer) {
            alert("Sloj 'VODjICE' nije pronađen!");
            return;
        }
        
        // Pronađi grupu "DESNA" unutar sloja "VODjICE"
        var desnaGroup = findGroupByName(vodjiceLayer, "DESNA");
        if (!desnaGroup) {
            alert("Grupa 'DESNA' nije pronađena!");
            return;
        }
        
        // Pronađi grupe unutar grupe "DESNA"
        var klinoviGroup = findGroupByName(desnaGroup, "KLINOVI");
        var maliKlinoviGroup = findGroupByName(desnaGroup, "mali_KLINOVI");
        
        // Dijagnostika - prikaži šta je pronađeno
        // var debugInfo = "Upravljanje vidljivošću:\n";
        // debugInfo += "useMaliKlinovi: " + useMaliKlinovi + "\n";
        // debugInfo += "DESNA grupa: " + (desnaGroup ? "pronađena" : "nije pronađena") + "\n";
        // debugInfo += "KLINOVI grupa: " + (klinoviGroup ? "pronađena" : "nije pronađena") + "\n";
        // debugInfo += "mali_KLINOVI grupa: " + (maliKlinoviGroup ? "pronađena" : "nije pronađena") + "\n";
        
        // $.writeln(debugInfo);
        // Koristi male klinove - obriši KLINOVI, prikaži mali_KLINOVI
        if (useMaliKlinovi) {
            if (klinoviGroup) {
                klinoviGroup.remove(); // Obriši grupu KLINOVI
                // debugInfo += "KLINOVI obrisan\n";
            }
            if (maliKlinoviGroup) {
                maliKlinoviGroup.visible = true;
                maliKlinoviGroup.hidden = false;
                // debugInfo += "mali_KLINOVI postavljen na: " + maliKlinoviGroup.visible + "\n";
            }
        } else {
            // Koristi velike klinove - obriši mali_KLINOVI, prikaži KLINOVI
            if (klinoviGroup) {
                klinoviGroup.visible = true;
                klinoviGroup.hidden = false;
                // debugInfo += "KLINOVI postavljen na: " + klinoviGroup.visible + "\n";
            }
            if (maliKlinoviGroup) {
                maliKlinoviGroup.remove(); // Obriši grupu mali_KLINOVI
                // debugInfo += "mali_KLINOVI obrisan\n";
            }
        }
        
        // alert(debugInfo);
        
    } catch (e) {
        // Ako grupe ne postoje, ignoriši grešku
        // $.writeln("Greška pri upravljanju vidljivošću: " + e.message);
    }
}

// Glavna funkcija
function main() {
    // Pitaj korisnika da li želi male klinove
    var useMaliKlinovi = confirm("ŽELITE LI MALE KLINOVE?", true, "IZBOR KLINOVA");
    
    // Upravljaj vidljivošću slojeva
    manageKlinoviVisibility(app.activeDocument, useMaliKlinovi);
    
    // Automatski proveri postojeće boje u MOVE TABELI
    var existingColors = checkColorsInMoveTable();
    if (!existingColors) {
        return; // Greška već prikazana
    }
    
    // Prikaži informativni dijalog
    var izborKlinova = showAutoDialog(existingColors);
    
    if (!izborKlinova) {
        // Korisnik je otkazao, izađi iz skripte
        return;
    }
    
    // Postavi parametre na osnovu izbora
    var klinoviParams = {
        razmak: useMaliKlinovi ? 72 : 128.0654,
        offset: useMaliKlinovi ? 73.36 : 130.5327
    };
    
    // Pronalazak sloja "VODjICE"
    var vodjiceLayer = findLayerByName("VODjICE");
    if (vodjiceLayer) {

        // Pronalazak grupe "DESNA" unutar sloja "VODjICE"
        var desnaGroup = findGroupByName(vodjiceLayer, "DESNA");
        if (desnaGroup) {

            // Dinamički naziv klinova
            var klinoviGroupName = useMaliKlinovi ? "mali_KLINOVI" : "KLINOVI";
            
            // Pronalazak grupe klinova unutar grupe "DESNA"
            var klinoviGroup = findGroupByName(desnaGroup, klinoviGroupName);
            if (klinoviGroup) {

                // Pronalazak specifičnih grupa unutar "KLINOVI"
                var cyanKlin = findGroupByName(klinoviGroup, "CYAN KLIN");
                var magentaKlin = findGroupByName(klinoviGroup, "MAGENTA KLIN");
                var yellowKlin = findGroupByName(klinoviGroup, "YELLOW KLIN");
                var blackKlin = findGroupByName(klinoviGroup, "BLACK KLIN");

                // Pronalazak grupe "DESNI DONJI PASER" unutar "DESNA"
                var desniDonjiPaser = findGroupByName(desnaGroup, "DESNI DONJI PASER");
                
                // Pronalazak grupe "process_tekst" unutar "DESNA"
                var processTekstGroup = findGroupByName(desnaGroup, "process_tekst");

                // Ako su klinovi i paser pronađeni, prikaži dijalog
                if (cyanKlin && magentaKlin && yellowKlin && blackKlin && desniDonjiPaser) {
                    
                    // Pozicija grupe "DESNI DONJI PASER"
                    var yPosDDP = desniDonjiPaser.position[1];
                    
                    // Postavi vidljivost i pripremi pozicije (obrnuta logika)
                    var currentY = yPosDDP + klinoviParams.offset; // Dinamički offset
                    
                    // BLACK KLIN + slovo 'K'
                    if (!izborKlinova.black) {
                        blackKlin.visible = true;
                        blackKlin.position = [blackKlin.position[0], currentY];
                        currentY += klinoviParams.razmak; // Dinamički razmak
                    } else {
                        blackKlin.remove(); // Obriši klin
                        if (processTekstGroup) {
                            var textK = findTextByName(processTekstGroup, "ispis_K");
                            if (textK) textK.remove(); // Obriši slovo K
                        }
                        // NE povećavaj currentY - klin je obrisan, sledeći klin dolazi na njegovo mesto
                    }
                    
                    // YELLOW KLIN + slovo 'Y'
                    if (!izborKlinova.yellow) {
                        yellowKlin.visible = true;
                        yellowKlin.position = [yellowKlin.position[0], currentY];
                        currentY += klinoviParams.razmak; // Dinamički razmak
                    } else {
                        yellowKlin.remove(); // Obriši klin
                        if (processTekstGroup) {
                            var textY = findTextByName(processTekstGroup, "ispis_Y");
                            if (textY) textY.remove(); // Obriši slovo Y
                        }
                        // NE povećavaj currentY - klin je obrisan, sledeći klin dolazi na njegovo mesto
                    }
                    
                    // MAGENTA KLIN + slovo 'M'
                    if (!izborKlinova.magenta) {
                        magentaKlin.visible = true;
                        magentaKlin.position = [magentaKlin.position[0], currentY];
                        currentY += klinoviParams.razmak; // Dinamički razmak
                    } else {
                        magentaKlin.remove(); // Obriši klin
                        if (processTekstGroup) {
                            var textM = findTextByName(processTekstGroup, "ispis_M");
                            if (textM) textM.remove(); // Obriši slovo M
                        }
                        // NE povećavaj currentY - klin je obrisan, sledeći klin dolazi na njegovo mesto
                    }
                    
                    // CYAN KLIN + slovo 'C'
                    if (!izborKlinova.cyan) {
                        cyanKlin.visible = true;
                        cyanKlin.position = [cyanKlin.position[0], currentY];
                    } else {
                        cyanKlin.remove(); // Obriši klin
                        if (processTekstGroup) {
                            var textC = findTextByName(processTekstGroup, "ispis_C");
                            if (textC) textC.remove(); // Obriši slovo C
                        }
                        // NE povećavaj currentY - poslednji klin, nema potrebe
                    }
                    
                    // Pozicioniranje grupe "process_tekst" sa 4px razmakom između slova
                    if (processTekstGroup) {
                        var imePoslaText = findTextByName(desnaGroup, "IME POSLA");
                        if (imePoslaText) {
                            var imePoslaTop = imePoslaText.top;
                            var imePoslaHeight = imePoslaText.height;
                            processTekstGroup.top = imePoslaTop - imePoslaHeight - 7;
                            
                            // Postavi 4px razmak između slova u process_tekst
                            var textFrameY = imePoslaTop - imePoslaHeight - 7;
                            var textFrameHeight = 0;
                            
                            // Pronađi sva preostala slova i postavi razmak
                            var remainingTexts = [];
                            var belaText = null;
                            
                            for (var i = 0; i < processTekstGroup.textFrames.length; i++) {
                                var textFrame = processTekstGroup.textFrames[i];
                                if (textFrame.name === "ispis_BELA") {
                                    belaText = textFrame; // Nađi "Bela"
                                } else if (textFrame.name.indexOf("ispis_") >= 0) {
                                    remainingTexts.push(textFrame); // Ostala slova
                                }
                            }
                            
                            // Sortiraj po CMYK redosledu (C, M, Y, K)
                            remainingTexts.sort(function(a, b) {
                                var order = {"ispis_C": 0, "ispis_M": 1, "ispis_Y": 2, "ispis_K": 3};
                                return order[a.name] - order[b.name];
                            });
                            
                            // Postavi pozicije: Bela na vrhu, zatim C, M, Y, K sa 2px razmakom
                            var currentTextY = textFrameY;
                            
                            // Prvo postavi "Bela" na vrh
                            if (belaText) {
                                belaText.top = currentTextY;
                                currentTextY -= belaText.height + 2; // 2px razmak
                            }
                            
                            // Zatim postavi ostala slova
                            for (var j = 0; j < remainingTexts.length; j++) {
                                remainingTexts[j].top = currentTextY;
                                currentTextY -= remainingTexts[j].height + 2; // 2px razmak
                            }
                        }
                    }
                    
                    // Pozicioniranje "SPOT BOJE" ispod "process_tekst" za 7px
                    var spotBojeText = findTextByName(desnaGroup, "SPOT BOJE");
                    if (spotBojeText && processTekstGroup) {
                        var processTekstTop = processTekstGroup.top;
                        var processTekstHeight = processTekstGroup.height;
                        spotBojeText.top = processTekstTop - processTekstHeight - 7;
                    }
                    
                    // Nema alert poruke - tiho izvršavanje
                    
                } else {
                    alert("Neke od grupa nisu pronađene.");
                }
            } else {
                alert("Grupa 'KLINOVI' nije pronađena.");
            }
        } else {
            alert("Grupa 'DESNA' nije pronađena.");
        }
    } else {
        alert("Sloj 'VODjICE' nije pronađen.");
    }
}

// Pokreni glavnu funkciju
main();
