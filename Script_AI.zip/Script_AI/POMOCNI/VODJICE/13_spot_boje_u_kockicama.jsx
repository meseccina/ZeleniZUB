//@target illustrator

// Funkcija za proveru da li ime boje treba biti izuzeto
function isExcluded(swatchName, excludeNames) {
    for (var j = 0; j < excludeNames.length; j++) {
        if (swatchName.toLowerCase().indexOf(excludeNames[j].toLowerCase()) !== -1) {
            return true;
        }
    }
    return false;
}

// Funkcija za prepoznavanje validnih Spot boja
function getValidSpotColors() {
    var validSpotColors = [];
    var excludeNames = ["Registration", "Rasklop", "_Bela_", "Passermarken", "Registrační", "TRANSPARENT"];

    // Dohvatanje swatches iz dokumenta
    var swatches = app.activeDocument.swatches;
    for (var i = 0; i < swatches.length; i++) {
        var swatch = swatches[i];

        // Provera da li je boja tipa SpotColor
        if (swatch.color.typename === "SpotColor") {
            var name = swatch.name;

            // Provera da li boja sadrži bilo koji od zabranjenih izraza
            if (!isExcluded(name, excludeNames)) {
                validSpotColors.push(swatch.color);
            }
        }
    }

    return validSpotColors;
}

// Funkcija za pronalaženje pravougaonika u grupi 'SPOT_KLIN'
function getTargetRectangles() {
    var doc = app.activeDocument;
    var layer, desnaGroup, spotKlinGroup;

    try {
        layer = doc.layers.getByName("VODjICE");
        desnaGroup = layer.groupItems.getByName("DESNA");
        spotKlinGroup = desnaGroup.groupItems.getByName("SPOT_KLIN");
    } catch (e) {
        return null;
    }

    var groupNames = ["prva_boja", "druga_boja", "treca_boja"];
    var rectNames = ["1_boja", "2_boja", "3_boja"];
    var rectangles = [];

    for (var i = 0; i < groupNames.length; i++) {
        var group, rect;
        try {
            group = spotKlinGroup.groupItems.getByName(groupNames[i]);
            rect = group.pathItems.getByName(rectNames[i]);

            // Proveravamo tip objekta
            if (rect && rect.typename === "PathItem") {
                rectangles.push({ group: group, rect: rect }); // Spremamo i grupu i pravougaonik
            }
        } catch (e) {
            return null;
        }
    }

    return rectangles;
}

// Funkcija za primenu boja na pravougaonike
function applyColorsToRectangles(spotColors, rectangles) {
    if (rectangles.length === 0) {
        return;
    }

    for (var i = 0; i < rectangles.length; i++) {
        var currentColor = spotColors[i];

        if (currentColor instanceof SpotColor) {
            rectangles[i].rect.fillColor = currentColor;
            rectangles[i].rect.filled = true;
        }
    }
}

// Funkcija za brisanje grupe koja sadrži pravougaonik
function deleteGroupContainingRectangle(rect) {
    try {
        if (rect && rect.parent && rect.parent.typename === "GroupItem") {
            var group = rect.parent;
            group.remove();
        }
    } catch (e) {
        alert("Greška prilikom brisanja grupe: " + e.message);
    }
}

// Glavna funkcija
function main() {
    var rectangles = getTargetRectangles();
    if (rectangles === null) return;

    var spotColors = getValidSpotColors();
    if (spotColors.length === 0) {
        return;
    }

    // Ako manje od 3 boje, brišemo višak grupa
    if (spotColors.length < 3) {
        for (var i = 0; i < rectangles.length; i++) {
            var rectGroup = rectangles[i].group;

            if (spotColors.length === 2 && rectGroup.name === "treca_boja") {
                deleteGroupContainingRectangle(rectangles[i].rect);
            } else if (spotColors.length === 1 && (rectGroup.name === "druga_boja" || rectGroup.name === "treca_boja")) {
                deleteGroupContainingRectangle(rectangles[i].rect);
            }
        }
    }

    applyColorsToRectangles(spotColors, rectangles);
}

// Pokretanje skripte
main();
