/**
 * Oboji objekat “glavna_vodjica” odabranom SPOT bojom u 75 % tintu,
 * s tim da sledeće SPOT boje ne budu ponuđene u dijalogu:
 *   Registration, Rasklop, _Bela_, Passermarken, Registrační, TRANSPARENT
 */
function main() {
    if (app.documents.length === 0) {
        alert("Nema otvorenih dokumenata.");
        return;
    }

    var doc = app.activeDocument;

    // ---------- Pomoćne funkcije za pretragu ----------
    function findGroupByName(container, targetName) {
        targetName = targetName.toLowerCase();
        for (var i = 0; i < container.groupItems.length; i++) {
            if (container.groupItems[i].name.toLowerCase() === targetName)
                return container.groupItems[i];
        }
        return null;
    }

    function findItemByName(container, targetName) {
        targetName = targetName.toLowerCase();

        for (var i = 0; i < container.pathItems.length; i++)
            if (container.pathItems[i].name.toLowerCase() === targetName)
                return container.pathItems[i];

        for (var j = 0; j < container.groupItems.length; j++)
            if (container.groupItems[j].name.toLowerCase() === targetName)
                return container.groupItems[j];

        for (var k = 0; k < container.compoundPathItems.length; k++)
            if (container.compoundPathItems[k].name.toLowerCase() === targetName)
                return container.compoundPathItems[k];

        for (var m = 0; m < container.textFrames.length; m++)
            if (container.textFrames[m].name.toLowerCase() === targetName)
                return container.textFrames[m];

        return null;
    }

    // ---------- Pronalaženje sloja / grupa / objekta ----------
    try {
        var slojVodjice = doc.layers.getByName("VODjICE");
    } catch (e) {
        alert("Nije pronađen sloj 'VODjICE'");
        return;
    }

    var grupaLeva = findGroupByName(slojVodjice, "LEVA");
    if (!grupaLeva) {
        alert("Nije pronađena grupa 'LEVA'");
        return;
    }

    var grupaCrnaVodjica = findGroupByName(grupaLeva, "CRNA VODJICA");
    if (!grupaCrnaVodjica) {
        alert("Nije pronađena grupa 'CRNA VODJICA'");
        return;
    }

    var cilj = findItemByName(grupaCrnaVodjica, "glavna_vodjica");
    if (!cilj) {
        alert("Nije pronađen objekat 'glavna_vodjica'");
        return;
    }

    // Selektuj objekat
    doc.selection = null;
    doc.selection = [cilj];

    // ---------- Dohvatanje SPOT boja, uz filter ----------
    function getSpotSwatches(doc) {
        var spots = [];
        var skipNames = {
            "registration": true,
            "[registration]": true,
            "rasklop": true,
            "_bela_": true,
            "passermarken": true,
            "registrační": true,
            "transparent": true
        };

        for (var i = 0; i < doc.swatches.length; i++) {
            var swatch = doc.swatches[i];
            if (swatch.color.typename === "SpotColor") {
                var nameNorm = swatch.name.toLowerCase().replace(/^\s+|\s+$/g, ""); // trim + lower
                if (skipNames[nameNorm]) continue; // preskoči zabranjene
                spots.push(swatch);
            }
        }
        return spots;
    }

    // ---------- Dijalog za izbor SPOT boje ----------
    function showSpotChooser(spots) {
        var dlg = new Window("dialog", "Izaberi SPOT boju");
        dlg.orientation = "column";
        dlg.alignChildren = ["left", "top"];

        var radioGroup = dlg.add("group");
        radioGroup.orientation = "column";

        var radios = [];
        for (var i = 0; i < spots.length; i++) {
            radios[i] = radioGroup.add("radiobutton", undefined, spots[i].name);
            if (i === 0) radios[i].value = true; // podrazumevano prva boja
        }

        var btnGroup = dlg.add("group");
        btnGroup.orientation = "row";
        btnGroup.alignment = "right";

        var okBtn = btnGroup.add("button", undefined, "OK", { name: "ok" });
        var cancelBtn = btnGroup.add("button", undefined, "Cancel", { name: "cancel" });

        var selectedIndex = -1;

        okBtn.onClick = function () {
            for (var i = 0; i < radios.length; i++) {
                if (radios[i].value) {
                    selectedIndex = i;
                    break;
                }
            }
            if (selectedIndex === -1) {
                alert("Izaberi boju!");
                return;
            }
            dlg.close();
        };

        cancelBtn.onClick = function () {
            selectedIndex = -1;
            dlg.close();
        };

        dlg.show();

        return selectedIndex === -1 ? null : spots[selectedIndex];
    }

    var spotSwatches = getSpotSwatches(doc);
    if (spotSwatches.length === 0) {
        alert("Nema SPOT boja (osim izuzetih) u dokumentu.");
        return;
    }

    var chosenSpot = showSpotChooser(spotSwatches);
    if (!chosenSpot) {
        alert("Nije izabrana nijedna boja.");
        return;
    }

    // ---------- Oboji objekat izabranom bojom (75 % tint) ----------
    var spotColor = new SpotColor();
    spotColor.spot = chosenSpot.color.spot;
    spotColor.tint = 75; // 75 %

    cilj.fillColor = spotColor;

}

main();
