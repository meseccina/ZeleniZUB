#target illustrator

(function () {
    if (app.documents.length === 0) return;
    var doc = app.activeDocument;

    // Sloj i grupa
    var vodjiceLayer;
    try { vodjiceLayer = doc.layers.getByName("VODjICE"); } catch (e) { return; }

    var desna = null;
    for (var i = 0; i < vodjiceLayer.groupItems.length; i++) {
        if (vodjiceLayer.groupItems[i].name === "DESNA") { desna = vodjiceLayer.groupItems[i]; break; }
    }
    if (!desna) return;

    // Tekst objekti
    var imePosla = findTextByName(desna, "IME POSLA");
    var textObj  = findTextByName(desna, "TEXT");
    var spotBoje = findTextByName(desna, "SPOT BOJE");
    if (!imePosla || !textObj || !spotBoje) return;

    var gap = 5; // px

    // Funkcija koja vraća visinu teksta
    function getHeight(textFrame) {
        return textFrame.height;
    }

    // Postavlja sledeći tekst vizuelno 10 px ispod prethodnog (za 90° CW)
    function setTextBelow(prevText, nextText, gap) {
        var prevTop = prevText.top;
        var prevHeight = getHeight(prevText);
        // Vizuelno dole = smanjenje Y vrednosti
        nextText.top = prevTop - prevHeight - gap;
    }

    // Postavi TEXT i SPOT BOJE
    setTextBelow(imePosla, textObj, gap);
    setTextBelow(textObj, spotBoje, gap);

    function findTextByName(container, name) {
        for (var j = 0; j < container.pageItems.length; j++) {
            if (container.pageItems[j].name === name && container.pageItems[j].typename === "TextFrame") return container.pageItems[j];
        }
        return null;
    }
})();
