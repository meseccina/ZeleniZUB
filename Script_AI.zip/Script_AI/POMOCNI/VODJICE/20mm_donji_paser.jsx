// Provera da li je Illustrator aktivan
if (app.documents.length > 0) {
    // Provera da li postoji selektovani objekat
    if (app.activeDocument.selection.length > 0) {
        // Dohvatanje trenutnog artboarda
        var currentArtboard = app.activeDocument.artboards[app.activeDocument.artboards.getActiveArtboardIndex()];
        var artboardRect = currentArtboard.artboardRect;
        
        // Pomeranje svakog selektovanog objekta
        for (var i = 0; i < app.activeDocument.selection.length; i++) {
            var selectedObject = app.activeDocument.selection[i];
            
            // Postavljanje donje ivice objekta na 20mm iznad donje ivice artboarda
            // 10mm = 32.598 pt
            selectedObject.top = artboardRect[3] + 32.598;
        }
        // Osvežavanje ekrana
        app.redraw();
    } else {
        alert("Nema selektovanih objekata!");
    }
} else {
    alert("Nema otvorenih dokumenata u Illustratoru!");
}
