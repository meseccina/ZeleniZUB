// ================================
// ERROR HANDLER - Robustna obrada gresaka
// ================================

function runScriptSafe(scriptName, directoryPath) {
    var scriptFile = new File(directoryPath + scriptName);
    
    if (!scriptFile.exists) {
        logError("Skripta ne postoji: " + scriptName);
        return false;
    }
    
    try {
        $.evalFile(scriptFile);
        logInfo("Uspešno izvršena: " + scriptName);
        return true;
    } catch (e) {
        logError("Greška u " + scriptName + ": " + e.message);
        return false;
    }
}

function logError(message) {
    $.writeln("ERROR: " + message);
    // Može se dodati logovanje u fajl
}

function logInfo(message) {
    $.writeln("INFO: " + message);
}

function validateDocument() {
    if (app.documents.length === 0) {
        throw new Error("Nema otvorenih dokumenata");
    }
    
    var doc = app.activeDocument;
    if (!doc.artboards.length) {
        throw new Error("Document nema artboard");
    }
    
    return true;
}
