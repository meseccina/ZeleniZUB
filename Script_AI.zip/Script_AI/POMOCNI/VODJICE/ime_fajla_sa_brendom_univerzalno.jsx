//@target illustrator

// Proveri da li ima otvoren dokument
if (app.documents.length > 0) {
    // Pronalaženje sloja "VODjICE"
    var vodjiceLayer = null;
    for (var i = 0; i < app.activeDocument.layers.length; i++) {
        if (app.activeDocument.layers[i].name === "VODjICE") {
            vodjiceLayer = app.activeDocument.layers[i];
            break;
        }
    }
    
    if (vodjiceLayer) {
        // Pronalaženje grupe "DESNA" unutar sloja "VODjICE"
        var desnaGroup = null;
        for (var j = 0; j < vodjiceLayer.groupItems.length; j++) {
            if (vodjiceLayer.groupItems[j].name === "DESNA") {
                desnaGroup = vodjiceLayer.groupItems[j];
                break;
            }
        }
        
        if (desnaGroup) {
            // Pronalaženje tekstualnog objekta "IME POSLA" unutar grupe "DESNA"
            var imePoslaText = null;
            for (var k = 0; k < desnaGroup.textFrames.length; k++) {
                if (desnaGroup.textFrames[k].name === "IME POSLA") {
                    imePoslaText = desnaGroup.textFrames[k];
                    break;
                }
            }
            
            if (imePoslaText) {
                // Koristimo pronađeni "IME POSLA" objekat
                var selectedObject = imePoslaText;
        // Dohvatanje putanje do trenutnog dokumenta
        var filePath = app.activeDocument.fullName.fsName;

        var projectName = "";
        var formattedText = "";

        // Detekcija tipa posla i izvlaženje brenda
        if (filePath.indexOf("\\MOVE\\") > 0) {
            // MOVE logika
            var movePathStart = filePath.indexOf("\\MOVE\\") + "\\MOVE\\".length;
            var movePathEnd = filePath.indexOf("\\", movePathStart);
            projectName = filePath.substring(movePathStart, movePathEnd);
            
        } else if (filePath.indexOf("\\Chips WAY\\") > 0) {
            // CHIPS WAY logika
            projectName = "Chips WAY"; // Fiksno ime za CHIPS WAY poslove
            
        } else if (filePath.indexOf("M:\\") === 0) {
            // M: je mapiran ka \\Nas6bf537\flexo\MOVE\
            var mPathStart = 3; // Posle "M:\"
            var mPathEnd = filePath.indexOf("\\", mPathStart);
            projectName = filePath.substring(mPathStart, mPathEnd);
            
        } else {
            alert("Nepoznata putanja dokumenta. Očekivane putanje:\\n- \\\\Nas6bf537\\flexo\\MOVE\\...\\n- \\\\Nas6bf537\\flexo\\Chips WAY\\...\\n- M:\\... (mapirani disk)\\n\\nTrenutna putanja: " + filePath);
            // Ne možemo da koristimo return van funkcije, pa izađemo iz if bloka
        }

        // Proveri da li je projectName pronađen
        if (projectName === "") {
            alert("Nije moguće izvući naziv projekta iz putanje. Skripta se zaustavlja.");
        } else {

        // Dohvatanje imena fajla
        var fileName = app.activeDocument.name;

        // Razdvajanje imena fajla na delove prema " - "
        var fileParts = fileName.split(" - ");

        // Ukloni poslednji deo (verzija i ekstenzija)
        var lastPart = fileParts[fileParts.length - 1];
        if (lastPart.indexOf("_v") > 0 || lastPart.indexOf(".ai") > 0) {
            fileParts = fileParts.slice(0, -1);
        }

        // Formiranje teksta sa prva 3 dela iz imena fajla
        var fileText = fileParts.slice(0, 3).join(" - ");
        formattedText = projectName + " - " + fileText;

        // Čuvanje originalnog formata selektovanog teksta (font, veličina, poravnanje)
        var originalTextRange = selectedObject.textRange;

        // Brisanje prethodnog teksta
        selectedObject.contents = "";

        // Postavljanje novog formata teksta u selektovani objekat
        selectedObject.contents = formattedText;

        // Vraćanje originalnog formata teksta
        selectedObject.textRange.characterAttributes = originalTextRange.characterAttributes;
        selectedObject.textRange.paragraphAttributes = originalTextRange.paragraphAttributes;

        } // Zatvori else blok za projectName proveru

            } else {
                alert("Tekstualni objekat 'IME POSLA' nije pronađen unutar grupe 'DESNA'.");
            }
        } else {
            alert("Grupa 'DESNA' nije pronađena unutar sloja 'VODjICE'.");
        }
    } else {
        alert("Sloj 'VODjICE' nije pronađen.");
    }
} else {
    alert("Nema otvorenog dokumenta. Molimo vas da otvorite dokument pre pokretanja skripte.");
}
