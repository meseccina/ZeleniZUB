//@target illustrator

// Provera da li ima otvoren dokument
if (app.documents.length > 0) {
    // Dohvatanje referenci na trenutni selektovani tekstualni objekat
    var selectedObject = app.activeDocument.selection[0];

    // Provera da li postoji selektovani tekstualni objekat
    if (selectedObject && selectedObject.typename === "TextFrame") {
        // Dohvatanje trenutnog imena fajla
        var fileName = app.activeDocument.name;

        // Niz dodatnih tekstova koje treba proveriti i ukloniti
        var additionalTexts = [" - SKRACENO.ai", " - MONTAZA.ai", " - DOT.ai"];

        // Iteracija kroz dodatne tekstove i uklanjanje ako postoje
        for (var i = 0; i < additionalTexts.length; i++) {
            var additionalText = additionalTexts[i];

            if (fileName.indexOf(additionalText) !== -1) {
                fileName = fileName.replace(additionalText, "");
            }
        }

        // Postavljanje teksta selektovanog objekta na novo ime fajla
        selectedObject.contents = fileName;
    } else {
        alert("Tekstualni objekat nije selektovan. Molimo vas da selektujete tekst pre pokretanja skripte.");
    }
} else {
    alert("Nema otvorenog dokumenta. Molimo vas da otvorite dokument pre pokretanja skripte.");
}
