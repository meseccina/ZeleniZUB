//@target illustrator

// Provera da li ima otvoren dokument
if (app.documents.length > 0) {
    // Dohvatanje referenci na trenutni aktivni artboard i selektovani objekat
    var activeArtboard = app.activeDocument.artboards[app.activeDocument.artboards.getActiveArtboardIndex()];
    var selectedObject = app.activeDocument.selection[0];

    // Provera da li postoji selektovani objekat
    if (selectedObject) {
        // Dohvatanje granica selektovanog objekta
        var bounds = selectedObject.visibleBounds;

        // Izračunavanje sredine artboarda po Y osi
        var centerY = (activeArtboard.artboardRect[1] + activeArtboard.artboardRect[3]) / 2;

        // Izračunavanje pomaka po Y osi kako bi se objekat centrirao
        var deltaY = centerY - (bounds[1] + bounds[3]) / 2;

        // Pomeranje objekta
        selectedObject.translate(0, deltaY);
    } else {
        alert("Nije selektovan objekat. Molimo vas da selektujete objekat pre pokretanja skripte.");
    }
} else {
    alert("Nema otvorenog dokumenta. Molimo vas da otvorite dokument pre pokretanja skripte.");
}
