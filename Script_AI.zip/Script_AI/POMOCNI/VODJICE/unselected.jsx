// Proveri da li postoje selektovani objekti
if (app.activeDocument.selection.length > 0) {
    // Unselectuj sve objekte
    app.activeDocument.selection = null;

} 
