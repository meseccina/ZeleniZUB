// ================================
// VODJICE UTILS - Zajedničke funkcije
// ================================

#target illustrator

// Globalne promenljive za keširanje
var _cachedElements = null;
var _artboardInfo = null;

// ================================
// ARTBOARD FUNKCIJE
// ================================

function getArtboardInfo() {
    if (_artboardInfo) return _artboardInfo;
    
    var artboard = app.activeDocument.artboards[0];
    var artboardRect = artboard.artboardRect;
    
    _artboardInfo = {
        x1: artboardRect[0],
        y1: artboardRect[1],
        x2: artboardRect[2],
        y2: artboardRect[3],
        width: artboardRect[2] - artboardRect[0],
        height: Math.abs(artboardRect[3] - artboardRect[1]),
        centerX: (artboardRect[0] + artboardRect[2]) / 2,
        centerY: (artboardRect[1] + artboardRect[3]) / 2
    };
    
    return _artboardInfo;
}

// ================================
// PRONALAŽENJE ELEMENATA
// ================================

function findVodjiceLayer() {
    if (_cachedElements && _cachedElements.vodjiceLayer) {
        return _cachedElements.vodjiceLayer;
    }
    
    var doc = app.activeDocument;
    var layer = null;
    
    // Probaj različite varijante imena
    var possibleNames = ["VODjICE", "VODJICE", "Vodjice"];
    
    for (var i = 0; i < possibleNames.length; i++) {
        try {
            layer = doc.layers.getByName(possibleNames[i]);
            if (layer) break;
        } catch (e) {
            // Nastavi dalje ako ne postoji
        }
    }
    
    if (!_cachedElements) _cachedElements = {};
    _cachedElements.vodjiceLayer = layer;
    
    return layer;
}

function findGroupInLayer(layer, groupName) {
    if (!layer) return null;
    
    try {
        return layer.groupItems.getByName(groupName);
    } catch (e) {
        return null;
    }
}

function findLevaGroup() {
    if (_cachedElements && _cachedElements.levaGroup) {
        return _cachedElements.levaGroup;
    }
    
    var vodjiceLayer = findVodjiceLayer();
    var levaGroup = findGroupInLayer(vodjiceLayer, "LEVA");
    
    if (!_cachedElements) _cachedElements = {};
    _cachedElements.levaGroup = levaGroup;
    
    return levaGroup;
}

function findDesnaGroup() {
    if (_cachedElements && _cachedElements.desnaGroup) {
        return _cachedElements.desnaGroup;
    }
    
    var vodjiceLayer = findVodjiceLayer();
    var desnaGroup = findGroupInLayer(vodjiceLayer, "DESNA");
    
    if (!_cachedElements) _cachedElements = {};
    _cachedElements.desnaGroup = desnaGroup;
    
    return desnaGroup;
}

// ================================
// LEVA VODJICA ELEMENTI
// ================================

function getLevaVodjicaElements() {
    if (_cachedElements && _cachedElements.levaElements) {
        return _cachedElements.levaElements;
    }
    
    var levaGroup = findLevaGroup();
    if (!levaGroup) return null;
    
    var elements = {
        crnaVodjica: findGroupInLayer(levaGroup, "CRNA VODJICA"),
        srednjiPaser: findGroupInLayer(levaGroup, "LEVI SREDNJI PASER"),
        donjiPaser: findGroupInLayer(levaGroup, "LEVI DONJI PASER")
    };
    
    if (!_cachedElements) _cachedElements = {};
    _cachedElements.levaElements = elements;
    
    return elements;
}

// ================================
// POZICIONIRANJE FUNKCIJE
// ================================

function positionElement(element, x, y) {
    if (!element) {
        alert("Element ne postoji za pozicioniranje");
        return false;
    }
    
    element.position = [x, y];
    return true;
}

function positionLevaCrnaVodjica() {
    var elements = getLevaVodjicaElements();
    var artboard = getArtboardInfo();
    
    if (!elements || !elements.crnaVodjica) {
        alert("CRNA VODJICA nije pronađena");
        return false;
    }
    
    // Zadrži trenutnu X poziciju, postavi samo Y poziciju na gornju ivicu
    var currentX = elements.crnaVodjica.position[0];
    return positionElement(elements.crnaVodjica, currentX, artboard.y1);
}

function positionLevaSrednjiPaser() {
    var elements = getLevaVodjicaElements();
    var artboard = getArtboardInfo();
    
    if (!elements || !elements.srednjiPaser) {
        alert("LEVI SREDNJI PASER nije pronađen");
        return false;
    }
    
    // Koristi istu logiku kao sredisnji_paser.jsx - relativno pozicioniranje
    var bounds = elements.srednjiPaser.visibleBounds;
    var centerY = artboard.centerY;
    var deltaY = centerY - (bounds[1] + bounds[3]) / 2;
    
    elements.srednjiPaser.translate(0, deltaY);
    return true;
}

function positionLevaDonjiPaser() {
    var elements = getLevaVodjicaElements();
    var artboard = getArtboardInfo();
    
    if (!elements || !elements.donjiPaser) {
        alert("LEVI DONJI PASER nije pronađen");
        return false;
    }
    
    // Koristi istu logiku kao 20mm_donji_paser.jsx - postavljanje top svojstva
    elements.donjiPaser.top = artboard.y2 + 56.6929; // 20mm = 56.6929 pt
    return true;
}

// ================================
// ČIŠĆENJE FUNKCIJE
// ================================

function očistiTempObjekte() {
    var levaGroup = findLevaGroup();
    var desnaGroup = findDesnaGroup();
    
    var groupsToClean = [];
    if (levaGroup) groupsToClean.push(levaGroup);
    if (desnaGroup) groupsToClean.push(desnaGroup);
    
    var tempNames = ["LEVA BRISI ME", "DESNA BRISI ME"];
    
    for (var g = 0; g < groupsToClean.length; g++) {
        var group = groupsToClean[g];
        for (var i = group.pageItems.length - 1; i >= 0; i--) {
            var item = group.pageItems[i];
            for (var j = 0; j < tempNames.length; j++) {
                if (item.name === tempNames[j]) {
                    item.remove();
                    break;
                }
            }
        }
    }
}

// ================================
// INICIJALIZACIJA
// ================================

function initLevaVodjica() {
    var levaGroup = findLevaGroup();
    var artboard = getArtboardInfo();
    
    // 1. Postavi LEVA grupu na gornju levu ivicu artboarda SAMO ako nije već na pravom mestu
    if (levaGroup && artboard) {
        var currentX = levaGroup.position[0];
        var targetX = artboard.x1;
        
        // Pomeri grupu SAMO ako nije već na pravom X mestu (sa tolerancijom od 0.1mm)
        if (Math.abs(currentX - targetX) > 0.283) { // 0.1mm = 0.283 pt
            levaGroup.position = [targetX, artboard.y1];
        }
    }
    
    // 2. Odmah očisti "LEVA BRISI ME" objekte nakon pozicioniranja
    očistiTempObjekte();
}

// ================================
// DEBUG FUNKCIJE
// ================================

function debugElements() {
    var elements = getLevaVodjicaElements();
    var artboard = getArtboardInfo();
    
    $.writeln("=== DEBUG VODJICE ===");
    $.writeln("Artboard: " + JSON.stringify(artboard));
    $.writeln("VODjICE layer: " + (findVodjiceLayer() ? "Found" : "Not found"));
    $.writeln("LEVA group: " + (findLevaGroup() ? "Found" : "Not found"));
    $.writeln("CRNA VODJICA: " + (elements && elements.crnaVodjica ? "Found" : "Not found"));
    $.writeln("LEVI SREDNJI PASER: " + (elements && elements.srednjiPaser ? "Found" : "Not found"));
    $.writeln("LEVI DONJI PASER: " + (elements && elements.donjiPaser ? "Found" : "Not found"));
}
