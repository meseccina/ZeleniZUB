// Provjerava ima li odabranih objekata
if (app.selection.length > 0) {
    // Dohvaća selektovani objekt
    var selectedObject = app.selection[0];
    
    // Dohvaća trenutni artboard
    var currentArtboard = app.activeDocument.artboards[app.activeDocument.artboards.getActiveArtboardIndex()];
    
    // Postavlja donju (Y) poziciju odabranog objekta na donju granicu artboarda
    selectedObject.top = currentArtboard.artboardRect[3]; // Donja granica artboarda
} else {
    alert("Nema odabranih objekata.");
}


// Provera da li je neki objekat selektovan
if (app.selection.length > 0) {
    // Uzimanje visine prvog selektovanog objekta
    var selectedObject = app.selection[0];
    var objectHeight = selectedObject.height;

    // Pomeranje objekta za visinu po Y osi
    selectedObject.top = selectedObject.top + objectHeight;
} else {
    alert("Nema selektovanog objekta!");
}

// Provera da li je Illustrator aktivan
if (app.documents.length > 0) {
    // Provera da li postoji selektovani objekat
    if (app.activeDocument.selection.length > 0) {
        // Pomeranje svakog selektovanog objekta
        for (var i = 0; i < app.activeDocument.selection.length; i++) {
            var selectedObject = app.activeDocument.selection[i];
            // Pomeranje objekta po Y osi
            selectedObject.top += 52.4402;
        }
        // Osvežavanje ekrana
        app.redraw();
    } else {
        alert("Nema selektovanih objekata!");
    }
} else {
    alert("Nema otvorenih dokumenata u Illustratoru!");
}