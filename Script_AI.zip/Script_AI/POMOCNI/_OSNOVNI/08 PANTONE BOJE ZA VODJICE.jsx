//@target illustrator

if (app.documents.length > 0) {
    var doc = app.activeDocument;
    var swatches = doc.swatches;

    if (swatches.length > 0) {
        // Provera da li postoji selektovani tekstualni objekat
        if (app.selection.length > 0 && app.selection[0].typename === "TextFrame") {
            var textFrame = app.selection[0];

            // Brisanje starog teksta
            textFrame.textRange.contents = "";

            // Prolazimo kroz sve boje u paleti
            for (var i = 0; i < swatches.length; i++) {
                var swatch = swatches[i];
                var swatchName = swatch.name.replace("PANTONE ", "P").replace(" C", "c");

                // Provera da li je boja tipa SpotColor i da li njeno ime ne sadrži "[Registration]"
                if (swatch.color.typename === "SpotColor" && swatchName.indexOf("[Registration]", "Rasklop") === -1)
                if (swatch.color.typename === "SpotColor" && swatchName.indexOf("Rasklop") === -1)
                if (swatch.color.typename === "SpotColor" && swatchName.indexOf("_Bela_") === -1)
				if (swatch.color.typename === "SpotColor" && swatchName.indexOf("[Passermarken]") === -1)						
                if (swatch.color.typename === "SpotColor" && swatchName.indexOf("[Registrační] 1") === -1) 
                if (swatch.color.typename === "SpotColor" && swatchName.indexOf("TRANSPARENT") === -1) {
                    // Uklanjanje razmaka ispred "PU"
                    swatchName = swatchName.replace(" PU", "PU");

                    var newTextRange = textFrame.textRange.duplicate();
                    newTextRange.fillColor = swatch.color; // Dodela boje tekstu
                    newTextRange.contents = swatchName + "  "; // Dodavanje razmaka
                    // Ažuriranje teksta
                }
            }
        } else {
            alert("Nije selektovan tekstualni objekat. Molimo vas da selektujete tekst pre pokretanja skripte.");
        }
    } else {
        alert("Nema definisanih boja u paleti dokumenta.");
    }
} else {
    alert("Nema otvorenog dokumenta. Molimo vas da otvorite dokument pre pokretanja skripte.");
}
