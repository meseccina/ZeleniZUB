#target illustrator

(function () {

    if (app.documents.length === 0) {
        alert("Nema otvorenog dokumenta.");
        return;
    }

    var doc = app.activeDocument;
    var removed = false;

    for (var i = doc.spots.length - 1; i >= 0; i--) {
        if (doc.spots[i].name === "Deleted Global Color") {
            doc.spots[i].remove();
            removed = true;
        }
    }

    if (removed) {
        alert("Phantom spot 'Deleted Global Color' je uklonjen.");
    } else {
        alert("Spot nije pronađen.");
    }

})();
