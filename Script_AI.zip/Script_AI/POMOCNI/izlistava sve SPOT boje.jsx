#target illustrator

(function () {

    if (app.documents.length === 0) {
        alert("Nema otvorenog dokumenta.");
        return;
    }

    var doc = app.activeDocument;
    var report = "SPOT DEFINICIJE U DOKUMENTU:\n\n";

    if (doc.spots.length === 0) {
        report += "Nema spot definicija.";
    } else {
        for (var i = 0; i < doc.spots.length; i++) {
            report += i + ": " + doc.spots[i].name + "\n";
        }
    }

    alert(report);

})();
